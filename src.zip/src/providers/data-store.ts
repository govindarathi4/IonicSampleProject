import { Injectable } from '@angular/core';
import { AlertController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Job } from  '../app/models/job';
import { Machine } from '../app/models/machine';
import { User } from '../app/models/user';
import { Template } from '../app/models/template';
import { Recording } from '../app/models/recording';
import { Storage } from '@ionic/storage';

@Injectable()
export class DataStore {

  jobs: Job[] = [];
  machines: Machine[] = [];
  templates: Template[] = [];

  constructor(public http: Http, public storage: Storage, public alertCtrl: AlertController) {
    // this.mockUser();
    this.mockCustomers();
    this.mockBuildings();
    this.mockMachines();
    this.mockJobs();
    this.mockBranches();
    this.mockTemplates();
  }


  // getCustomer(customerId){
  //   let customers = this.getCustomers();
  //   return customers[customerId];
  // }

  getBuildings(){
    return this.storage.get('buildings');
  }

  getMachines(){
    return this.storage.get('machines');
  }

  getTemplates(){
    return this.storage.get('templates');
  }

  getJobs() {
    return this.storage.get('jobs');
  }

  setJobs(passedJobs) {
    console.log("In Data Store Set Jobs", passedJobs);
    this.storage.set('jobs', JSON.stringify(passedJobs));
  }

  getBranches(){
    return this.storage.get('branches');
  }

  getCustomers(){
    return this.storage.get('customers');
  }

  getMachineType(min, max){
    let types = ["Chiller", "Fan", "Pump"]
    min = Math.ceil(min);
    max = Math.floor(max);
    // console.log(Math.floor(Math.random() * (max = min + 3)) + min);
    // console.log(types[Math.floor(Math.random() * (max = min + 3)) + min])
    return types[Math.floor(Math.random() * (max = min + 3)) + min];
  }

  getPreferredBranch() {
    return this.storage.get('preferredBranch');
  }

  setPreferredBranch(branch){
    this.storage.set('preferredBranch', branch);
  }

  getRecordings(){
    return this.storage.get('recordedJobs');
  }

  setRecordings(recordedMachines){
    this.storage.set('recordedJobs', JSON.stringify(recordedMachines));
  }

  getUsers(){
    return this.storage.get('users');
  }

  setUsers(users){
    this.storage.set('users', JSON.stringify(users))
  }

  mockBranches(){
    let arr = Array(5).fill({});
    let branches = arr.map((obj, i) => {
      return { id: i+1, branchName: `branch${i+1}`, location: `location${i}`, buildingIdArray: [`${i+1}`, `${i+2}`, `${i+3}`] };
    })
    console.log(branches);
    this.storage.set('branches', JSON.stringify(branches));
  }

  mockJobs(){
    let arr = Array(10).fill({});
    let status = Array(5).fill('open').concat(Array(5).fill('closed'));
    let jobs = arr.map((obj, i) => {
      return { jobId: i, jobName: `building${i} (` + new Date().toLocaleDateString() + `)`, buildingId: String(i), machineIdArray: [`${i+1}`, `${i+2}`, `${i+3}`], jobStatus: status[i], recordings: []};
    });
      this.storage.set('jobs', JSON.stringify(jobs))

  }

  mockCustomers(){
    let arr = Array(10).fill({ id: '', name: ''});
    let customers = arr.map((obj, i) => {
      return {id: i, name: `Customer${i}`};
    });
    this.storage.set('customers', JSON.stringify(customers));
  }

  mockBuildings(){
    let arr = Array(20).fill({ });
    let buildings = arr.map((obj, i) => {
      return {
        id: i,
        name: `Building${i}`,
        location: `Detroit`,
        customerId: i,
        coordinates: this.mockCoordinates(i)
      };
    });
    this.storage.set('buildings', JSON.stringify(buildings));
  }

  mockCoordinates(i){
    let coords = [
      {"locationName":"New York, NY", "coordinates": {latitude: 40.42287, longitude: -74.00199}},
      {"locationName":"Madison, WI", "coordinates": {latitude: 43.04284, longitude: -89.22506}},
      {"locationName":"Los Santos, CA", "coordinates": {latitude: 34.10396, longitude: -118.27065}},
      {"locationName":"A Place", "coordinates": {latitude: 39.17424, longitude: -104.18201}},
      {"locationName":"Another Place", "coordinates": {latitude: 34.16229, longitude: -88.44322}},
      {"locationName":"Someplace Else", "coordinates": {latitude: 34.16229, longitude: 155.04054}},
      {"locationName":"Los Angeles, CA", "coordinates": {latitude: 34.10396, longitude: -118.27065}},
      {"locationName":"Somewheres", "coordinates": {latitude: 39.17424, longitude: -104.18201}},
      {"locationName":"The spot", "coordinates": {latitude: 34.16229, longitude: -88.44322}},
      {"locationName":"Location", "coordinates": {latitude: 34.16229, longitude: 155.04054}},
      {"locationName":"Madison, WI", "coordinates": {latitude: 43.04284, longitude: -89.22506}},
      {"locationName":"New York, NY", "coordinates": {latitude: 40.42287, longitude: -74.00199}},
      {"locationName":"Los Santos, CA", "coordinates": {latitude: 34.10396, longitude: -118.27065}},
      {"locationName":"A Place", "coordinates": {latitude: 39.17424, longitude: -104.18201}},
      {"locationName":"Another Place", "coordinates": {latitude: 34.16229, longitude: -88.44322}},
      {"locationName":"Someplace Else", "coordinates": {latitude: 34.16229, longitude: 155.04054}},
      {"locationName":"Los Angeles, CA", "coordinates": {latitude: 34.10396, longitude: -118.27065}},
      {"locationName":"Somewheres", "coordinates": {latitude: 39.17424, longitude: -104.18201}},
      {"locationName":"The spot", "coordinates": {latitude: 34.16229, longitude: -88.44322}},
      {"locationName":"Location", "coordinates": {latitude: 34.16229, longitude: 155.04054}},
    ];
    return coords[i];
  }

  mockTemplates(){
    let templates = [
      {id: "1", templateName:"York YK/YT", machineType:"Chiller", make:"York", model:"YK", cooled:"Water"},
      // {id: "2", templateName:"York YK/YT", machineType:"Chiller", make:"York", model:"YT", cooled:"Water"},
      {id: "3", templateName:"York YS1", machineType:"Chiller", make:"York", model:"YS1", cooled:"Water"},
      {id: "4", templateName:"York YS2", machineType:"Chiller", make:"York", model:"YS2", cooled:"Water"},
      {id: "5", templateName:"York YS3", machineType:"Chiller", make:"York", model:"YS3", cooled:"Water"},
      {id: "6", templateName:"York YS4", machineType:"Chiller", make:"York", model:"YS4", cooled:"Water"},
      {id: "7", templateName:"York YS5", machineType:"Chiller", make:"York", model:"YS5", cooled:"Water"},
      {id: "8", templateName:"York YS6", machineType:"Chiller", make:"York", model:"YS6", cooled:"Water"},
      {id: "9", templateName:"York YS7", machineType:"Chiller", make:"York", model:"YS7", cooled:"Water"},
      {id: "10", templateName:"York DXS", machineType:"Chiller", make:"York", model:"DXS", cooled:"Both"},
      {id: "11", templateName:"York MTS", machineType:"Chiller", make:"York", model:"MTS", cooled:"Both"},
      {id: "12", templateName:"York CTS", machineType:"Chiller", make:"York", model:"CTS", cooled:"Both"},
      {id: "13", templateName:"York OT", machineType:"Chiller", make:"York", model:"OT", cooled:"Water"},
      {id: "14", templateName:"York WTS", machineType:"Chiller", make:"York", model:"WTS", cooled:"Both"},
      {id: "15", templateName:"York HT", machineType:"Chiller", make:"York", model:"HT", cooled:"Water"},
      {id: "16", templateName:"York YST", machineType:"Chiller", make:"York", model:"YST", cooled:"Water"},
      {id: "17", templateName:"York YG", machineType:"Chiller", make:"York", model:"YG", cooled:"Water"},
      {id: "18", templateName:"York OM", machineType:"Chiller", make:"York", model:"OM", cooled:"Water"},
      {id: "19", templateName:"Trane CVHF", machineType:"Chiller", make:"Trane", model:"CVHF", cooled:"Water"},
      {id: "20", templateName:"Trane CVHE", machineType:"Chiller", make:"Trane", model:"CVHE", cooled:"Water"},
      {id: "21", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"CHHB", cooled:"Both"},
      {id: "22", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"CHHN", cooled:"Both"},
      {id: "23", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"CHHP", cooled:"Both"},
      {id: "24", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"RTHB", cooled:"Both"},
      {id: "25", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"RTHA", cooled:"Both"},
      {id: "26", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"CHHC", cooled:"Both"},
      {id: "27", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"RTHD", cooled:"Both"},
      {id: "28", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"RTHC", cooled:"Both"},
      {id: "29", templateName:"Trane Screws", machineType:"Chiller", make:"Trane", model:"CHHT", cooled:"Both"},
      {id: "30", templateName:"Trane CVHA", machineType:"Chiller", make:"Trane", model:"CVHA", cooled:"Both"},
      {id: "31", templateName:"Trane CVHB/CHVB", machineType:"Chiller", make:"Trane", model:"CVHB", cooled:"Water"},
      {id: "32", templateName:"Carrier 19XR/19XRV", machineType:"Chiller", make:"Carrier", model:"19XR", cooled:"Water"},
      {id: "33", templateName:"Carrier 19XR/19XRV", machineType:"Chiller", make:"Carrier", model:"19XRV", cooled:"Water"},
      {id: "34", templateName:"Carrier 06N", machineType:"Chiller", make:"Carrier", model:"06N", cooled:"Air"},
      {id: "35", templateName:"Gearbox Driven Overhung Pump", machineType:"Pump", intermediaryType: "Gearbox", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "36", templateName:"Gearbox Driven Centerhung Pump", machineType:"Pump", intermediaryType: "Gearbox", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Centerhung"},
      {id: "37", templateName:"Coupled Overhung Pump", machineType:"Pump", intermediaryType: "Coupling", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "38", templateName:"Coupled Centerhung Pump", machineType:"Pump", intermediaryType: "Coupling", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Centerhung"},
      {id: "39", templateName:"Direct Drive Overhung Pump", machineType:"Pump", intermediaryType: "Direct Drive", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 0, drivenSupportStyle:"Centerhung"},
      {id: "40", templateName:"Vertical Coupled Centerhung Pump", machineType:"Pump", intermediaryType: "Coupling", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Vertical", drivenBearings: 2, drivenSupportStyle:"Centerhung"},
      {id: "41", templateName:"Vertical Coupled Overhung Pump", machineType:"Pump", intermediaryType: "Coupling", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Vertical", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "42", templateName:"Vertical Direct Drive Pump", machineType:"Pump", intermediaryType: "Direct Drive", drivenType:"Pump-Centrifugal", driveType:"Electric Motor", motorOrientation:"Vertical", drivenBearings: 0, drivenSupportStyle:"Overhung"},
      {id: "43", templateName:"Direct Drive Centrifugal Fan", machineType:"Fan", intermediaryType: "Direct Drive", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 0, drivenSupportStyle:"Overhung"},
      {id: "44", templateName:"Direct Drive Axial Fan", machineType:"Fan", intermediaryType: "Direct Drive", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 0, drivenSupportStyle:"Overhung"},
      {id: "45", templateName:"Coupled Overhung Axial Fan", machineType:"Fan", intermediaryType: "Coupling", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "46", templateName:"Coupled Overhung Centrifugal Fan", machineType:"Fan", intermediaryType: "Coupling", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "47", templateName:"Belt Driven Centrifugal Fan 2 Bearings", machineType:"Fan", intermediaryType: "Belt", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Centerhung"},
      {id: "48", templateName:"Belt Driven Centrifugal Fan 3 Bearings 2 Wheels", machineType:"Fan", intermediaryType: "Belt", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 3, drivenSupportStyle:"Centerhung"},
      {id: "49", templateName:"Belt Driven Centrifugal Fan 4 Bearings 3 Wheels", machineType:"Fan", intermediaryType: "Belt", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 4, drivenSupportStyle:"Centerhung"},
      {id: "50", templateName:"Belt Driven Vertical Cooling Tower", machineType:"Fan", intermediaryType: "Belt", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Vertical", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "51", templateName:"Gear Driven Horizontal Cooling Tower", machineType:"Fan", intermediaryType: "Gearbox", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 1, drivenSupportStyle:"Overhung"},
      {id: "0", templateName:"Vane Axial Fan - Motor Points Only", machineType:"Fan", intermediaryType: "Belt", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "52", templateName:"Other Machine", machineType:"Air Compressor", intermediaryType: "Belt", drivenType:"Fan-Axial", driveType:"Electric Motor", motorOrientation:"Horizontal", drivenBearings: 2, drivenSupportStyle:"Overhung"},
      {id: "53", templateName:"Another Machine", machineType:"Lawn Mower", intermediaryType: "Belt", drivenType:"Fan-Centrifugal", driveType:"Electric Motor", motorOrientation:"Vertical", drivenBearings: 3, drivenSupportStyle:"Overhung"},
    ]

    this.storage.set('templates', JSON.stringify(templates));
  }

  mockMachines(){
    let arr = Array(100).fill({});
    let points = Array(10).fill({ pointId: '', uploadPercent: 0});
    let pointArray = points.map((pt, j) => {
      return { pointId: j, uploadPercent: 100-j };
    });
    let pointLocations = Array(10).fill({ pointLocationId: '', pointLocationName: ''});
    let pointLocationArray = pointLocations.map((pl, n) => {
      return { pointLocationId: n, pointLocationName: n + ' Point'}
    })
    let imageData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFYAAABFCAYAAADQFBHCAAAKwGlDQ1BJQ0MgUHJvZmlsZQAASImVlwdUU1kax+97L52EFoiAlNCb9A7SawAF6SAqIYEQSggpqNhQGRzBEUVEBJQBHaqCFZCxIKLYBsGGfUAGBXUdLAiKyj5gCTu7Z3fP/s+55/3yvfu+93333XvOPwCQh5l8fiosC0AaTyQI8fWgR0XH0PEDAAEQIAA7QGOyhHz34OBAgGru+ld9uo/ORXXHZDrXv9//r5JjJwhZAEDBKMezhaw0lE+ho5vFF4gAQHLQuPZqEX+aa1FWEKAFonx2mjmz3DPN8bP8x8ycsBBPlCcAIJCZTAEHADIGjdMzWRw0D1kHZXMem8tDOQxlF1YSk41yEcqL0tLSp7kdZYP4f8rD+UvOeElOJpMj4dleZkTw4gr5qcy1/+dy/G+lpYrn3qGFDnKSwC8Eveqha1abkh4gYV780qA55rJn5s9wktgvfI5ZQs+YOWYzvQLmWJwS7j7HTMH8s1wRI2yOBekhkvy81KWBkvwJDAknCL1D5ziR68OY46yksMg5zuRGLJ1jYUpowPwcT0lcIA6R1Jwo8JH0mCacr43FnH+XKCnMb76GKEk97AQvb0mcFy6Zzxd5SHLyU4Pn60/1lcSFmaGSZ0XoBpvjZKZ/8HyeYMn6gDCQBMSAB9ggAQhAPEgHqUAE6MALcIEQ8NFfTIBuD1HCGtF0E57p/LUCLidJRHdHT1ECncFjmS6iW5pb2AEwfSZnP/kH2sxZg2jX52MZ7QA45KFBznyMqQ3AmRcAUD/Nx7Tfo9tlFwDnelhiQeZsbHrbAiwgARmgAJSBOtAGBsAEWAJb4ATcgDfwB0FoJ9FgJWCh/aShnawG68FmkAvywS6wF5SCCnAI1IKj4ARoAWfBRXAF3AA94B54DPrBEHgNRsEnMAlBEB6iQFRIGdKAdCFjyBKyh1wgbygQCoGioTiIA/EgMbQe2grlQ4VQKVQJ1UHHoTPQRega1As9hAagEeg99AVGYDKsAKvBerAZbA+7wwFwGLwC5sAZcBacA++ES+Aq+AjcDF+Eb8D34H74NTyGAEQKoSGaiAlij3giQUgMkogIkI1IHlKMVCGNSBvShdxB+pE3yGcMDkPF0DEmGCeMHyYcw8JkYDZidmBKMbWYZkwn5g5mADOK+Y6lYFWxxlhHLAMbheVgV2NzscXYauxp7GXsPewQ9hMOh6Ph9HF2OD9cNC4Ztw63A3cA14Rrx/XiBnFjeDxeGW+Md8YH4Zl4ET4Xvx9/BH8Bfxs/hJ8gSBE0CJYEH0IMgUfYQigm1BPOE24TXhImibJEXaIjMYjIJq4lFhAPE9uIt4hDxEmSHEmf5EwKIyWTNpNKSI2ky6QnpA9SUlJaUg5Sy6S4UtlSJVLHpK5KDUh9JsuTjcie5FiymLyTXENuJz8kf6BQKHoUN0oMRUTZSamjXKI8o0xIU6VNpRnSbOlN0mXSzdK3pd/KEGV0ZdxlVspkyRTLnJS5JfNGliirJ+spy5TdKFsme0a2T3ZMjipnIRcklya3Q65e7prcsDxeXk/eW54tnyN/SP6S/CAVoWpTPaks6lbqYepl6pACTkFfgaGQrJCvcFShW2FUUV7RWjFCcY1imeI5xX4aQtOjMWiptALaCdp92pcFagvcFyQs2L6gccHtBeNKC5XclBKU8pSalO4pfVGmK3srpyjvVm5RfqqCUTFSWaayWuWgymWVNwsVFjotZC3MW3hi4SNVWNVINUR1neoh1ZuqY2rqar5qfLX9apfU3qjT1N3Uk9WL1M+rj2hQNVw0uBpFGhc0XtEV6e70VHoJvZM+qqmq6acp1qzU7Nac1NLXCtfaotWk9VSbpG2vnahdpN2hPaqjobNEZ71Og84jXaKuvW6S7j7dLt1xPX29SL1tei16w/pK+gz9LP0G/ScGFANXgwyDKoO7hjhDe8MUwwOGPUawkY1RklGZ0S1j2NjWmGt8wLh3EXaRwyLeoqpFfSZkE3eTTJMGkwFTmmmg6RbTFtO3ZjpmMWa7zbrMvpvbmKeaHzZ/bCFv4W+xxaLN4r2lkSXLsszyrhXFysdqk1Wr1TtrY+sE64PWD2yoNktsttl02HyztbMV2Dbajtjp2MXZldv12SvYB9vvsL/qgHXwcNjkcNbhs6Oto8jxhOOfTiZOKU71TsOL9RcnLD68eNBZy5npXOnc70J3iXP52aXfVdOV6Vrl+txN243tVu320t3QPdn9iPtbD3MPgcdpj3FPR88Nnu1eiJevV55Xt7e8d7h3qfczHy0fjk+Dz6ivje8633Y/rF+A326/PoYag8WoY4z62/lv8O8MIAeEBpQGPA80ChQEti2Bl/gv2bPkyVLdpbylLUEgiBG0J+hpsH5wRvCvy3DLgpeVLXsRYhGyPqQrlBq6KrQ+9FOYR1hB2ONwg3BxeEeETERsRF3EeKRXZGFkf5RZ1IaoG9Eq0dzo1hh8TERMdczYcu/le5cPxdrE5sbeX6G/Ys2KaytVVqauPLdKZhVz1ck4bFxkXH3cV2YQs4o5Fs+IL48fZXmy9rFes93YReyRBOeEwoSXic6JhYnDHGfOHs5IkmtScdIbrie3lPsu2S+5Ink8JSilJmUqNTK1KY2QFpd2hifPS+F1pqunr0nv5Rvzc/n9GY4ZezNGBQGCaiEkXCFsFSmg5uem2ED8g3gg0yWzLHNidcTqk2vk1vDW3FxrtHb72pdZPlm/rMOsY63rWK+5fvP6gQ3uGyo3QhvjN3Zs0t6Us2ko2ze7djNpc8rm37aYbync8nFr5Na2HLWc7JzBH3x/aMiVzhXk9m1z2lbxI+ZH7o/d262279/+PY+ddz3fPL84/+sO1o7rP1n8VPLT1M7End0FtgUHd+F28Xbd3+26u7ZQrjCrcHDPkj3NRfSivKKPe1ftvVZsXVyxj7RPvK+/JLCkdb/O/l37v5Ymld4r8yhrKlct314+foB94PZBt4ONFWoV+RVffub+/KDSt7K5Sq+q+BDuUOahF4cjDnf9Yv9LXbVKdX71txpeTX9tSG1nnV1dXb1qfUED3CBuGDkSe6TnqNfR1kaTxsomWlP+MXBMfOzV8bjj908EnOg4aX+y8ZTuqfLT1NN5zVDz2ubRlqSW/tbo1t4z/mc62pzaTv9q+mvNWc2zZecUzxWcJ53POT91IevCWDu//c1FzsXBjlUdjy9FXbrbuayz+3LA5atXfK5c6nLvunDV+erZa47Xzly3v95yw/ZG802bm6d/s/ntdLdtd/Mtu1utPQ49bb2Le8/fdr198Y7XnSt3GXdv3Ft6r/d++P0HfbF9/Q/YD4Yfpj589yjz0eTj7CfYJ3lPZZ8WP1N9VvW74e9N/bb95wa8Bm4+D33+eJA1+PoP4R9fh3JeUF4Uv9R4WTdsOXx2xGek59XyV0Ov+a8n3+T+Te5v5W8N3p760+3Pm6NRo0PvBO+m3u/4oPyh5qP1x46x4LFnn9I+TY7nTShP1H62/9z1JfLLy8nVX/FfS74Zfmv7HvD9yVTa1BSfKWDOWAEEHXBiIgDvawCgRKPeAfXVJOlZzzwjaNbnzxD4Tzzrq2dkC0CNGwDh2QAEoh7lIDp0s2e99bRlCnMDsJWVZPxDwkQry9lcZNR5Yiempj6oAYBvA+CbYGpq8sDU1LfDaLEPAWjPmPXq08Kh/2AK9Wl4uRU3Yo9ng3/R3wHkLAv4wUiKCwAAAZtpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDUuNC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+ODY8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Njk8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KwMozUwAAId1JREFUeAHtnFmMpNd130/t3dXVXb1PT3fP1rOQM8MhOdyXcShScsRVdmBZsSIllh/iZ8dJEAR2Ar9YgJAYfogB58WGgQBZLCMxIoVKJCqhSVNyOCOSIjlbz9bTM73vVdW1L/79z1fVHLGb5KwQDfD2VNW33O/ec//37Pd+E2pQ7LNy2xEI3/YWP2vQEfgM2DvECNE71O51NVutVqxWyVss1mHhaNSKpZK9+uMf28uv/j/b1tdnj993lOsRuzo3a4f3H7CD+/dbWyJxXW3/vCuFbpeOrVarADBjb7/9tpUqFTt04G47dPfdFgkHQqH745cu2enxce4FIK1nlmxuetx2jN1nForby6/8wP7zf/lv1pVK2di+MctcmrDu9bwNxpO2DsCp+++xL37pJRvetu3njdsn9n9bOLYCkD/869fsW9/8pq3MTlujEbLu/j774rPP24vPvmD5Yt7m1lbtD7717y2fy9jnnnravvyrv2KFcsEuAfSvH3jULly8aP/jL/67TU1csumQ2bnTp+zo0KB99Ru/YZ17x+zk/3/T/uvLL1ss2W5f+cpXLB6LfeLgfp4VbhnYhjVsambG/vBb/84WrlyxeFsS7gvZ4vyC/eVffNtOnz5rc3NzFmtrs0QkZIceeMCuXL1q7733nu3Zs9vikYhNT0/b8eMn7L2fvmtDgHnffffa+yfftzOXL9uf/emfWqhes1k4fiK3bl2nTtns7KyNDA87biH6Yh6g4qOL7qmOSh0nqFGvW4R+w01pCu7c3u9bBrZSrthP3j5hs9NXrMrwKoW8oV8sEovaWnbNrl6Z4GrU5gHjiccfs0P3H7Xvvvw9e/2NH9v24SHbs3en/avf/R2bnZm3KIONwolr2axVy1XLRmL2AyYtxaQUyiWr1mo2OTHBJBy3K6iDRrVhPV1dlky2WQ1cKtLZAg8Uo6GwReNxBzK7vg6QYQuFQza/umyzV6bs3oMH7fDdhyxOnTtRbhnYOrO/ns1ZvVa1OgPr7O23tnjC5memHKj52TmrwDKNWt1OvPWWXcEQvfPm31ixWLRqpWi/9qtfthJ69MzJ9zBkFSuV86iSmpVKRevs7LRavWrMkrVFotwrWb3esBPvvGMVngdJhKNhA/0DGLt+uzp5xVZyOUv3dVsdHt02NGS7hkdsEklaYJJ7BqAtGrcIz7377k9t7+6xTy+wUaz5vv37LJ5osyhEh9CvGny6u9eKhZxlc1lL9/RZFGu+sLhkvYOI+sMP2Zuv/7W9deKEje0YAdxfwYjNWD6/bvH2dsut5awMiA0LW1e622q1CtwWtlX09OA2nj9yxMpMYqlUtonLExbp7rJO2okDagxujXd2WTGftzxtLBfWrdxA9KMxqyFdkxOXbX1pzQb2jDIvTNodKrfsxwrYQ4jU33/2OUt1dLjuajCQOnoxk81bLpcH3HVrb++wXTt3WW5pxSYvXHSRr8HFi8ur1tXZYV/76ldtaFDWPgSHN2x5ddWuTF6yudkpns/xO2NTVyZtmt8K0iHdGqF2lN96uYyy4UlGE2Y61ldWALFkK/Pz9j7cPT111VIYvaHt2y3Z1m5tqJtIKCJTcMfKLasCUZbuSts//+1/YWk45c+//eeWzazhk5Ytl11HlOtWYZDr6Lk+RDYJB06jJlLJlJ93oCMTHZ02vHPYduKnZt4/aQXqZjIZKxcLtJX1SUigC6vVGjr7qp07Ow4HRum3yw2QJjIP+EVUSh09HAaxBlKjP+CD42uWRV0No8P34g+fXnsLqut3DFQ1fFuALRQK9jcnfmJpOG69VLGMRBkQKnzi8Zjr0+zqCmKdtu6+Adu1ZwxOzvn53PySffsv/6cN9vbaYw8/bOfOjNvUyjL6t+yGp4re7QTAB/EmpM9Pnjppr/zgh5bsSNnunSNMTh+TV7NV2heAIdg2HkOPArzOoxgtGdgaYr84P2ehSt0y9J3o72X4d45lbwuwWaz4H//HP7YL5y/YAtZf1r2nt8fW1tYAqILujVoB/ZnDIu8c3Wn9g9stkVgBuLotzC3YwsKiLaUXUQkpO/bkY3bhwriLuvJD3d3dNrZ3rz31i79oZ8+cxQ07ZZcunLdUV6cNDPRanL6le8tEbSHcAU1eDONZQMdWUBEhVEAvHkQBb2V2agodHLECqimMhyB1cqfKbQFWBLYn4oHhQH+VGGQbLlKKCGoWoyTOiXFdKuIqerMbz4GRWRZdGMbg9Q8M2uLSkr322uv2+c/9PTv2xJP2v7//ffdV77nnHgTa7PW/etUuXrhga7QhKegD8CHC3ipcvLS4YOVCCT3eZnkArONJLGMopTpi0JUG7EhYOjVs/d1p1/98wbB3DtjI71FuddbEkaPDo5bN52wecSsjehqgyB4dGXH9Kh9S9eRraiKycFkCkZUnUMJyF4nOLsKJMeo88fjjbrD27ttrvaiOApx3BhUwh+umXMHRo0ft2LFjdgjvQKBn0cd9qBJJyjR+ryQoB1cKuDLPZjhfxzsZHt1h21BXS4uL1tHTbTt37nSa5Mvebu69bcDu3LXT7j/6AAYr4wDIgGiAMloSabljSVypOIGDwK1WMDJY8Sj+6cryMsYm0MeLS4v4nwP2hS98wVYA/ypR2jnC3hxGTEmbgwfvtqefecZ1rMCQuGOtPAC4TKQm9VPGcLYzAd24YSsrqxi0uv/GkaLunh7cr4br7/Fz5y1XXA+8EYhRPkMGLyzuvkVuuy3AigYFll049Pffd58tA9Tk5UkArVtvut3W0Xflcg1g5etGAD9n7ckkeIQBYgVjl6GBsPX19VOv6iHukcOHcIvC9sYbP3K3DTtvO+Aw1env73fDKCCkZnJMoAIKuWXi4G48D0V1UkUyfMplSFok/SlUSDLdaQlAli4Oo6IqeBALqKLZhQWkbh2auzeSRzeL723Rsdd2roH/09/8TRs/d85OvfuOdXe2Y4Xh2kibJ07kQYjz8uuAUSx5qrAIKBEAl1qQHpxGL/8V+vYXnnzcBqV/l8cBqcMBLRBxLSzMw7EdqIU2N44reBGaMPmwa/i/0u/iZuUFpFtXV9eY3HXrwXBJLQzDyeLKrlSnWbVkly+dsxw6Wjq5DWM3NrLDVdK147rR41sOELbqUJxy8PBh2zYyaplS2NYLOPQMukIoKZYSBy3iCeTWcw6yjJFuyAVbX88EoWwV8cVt+9zTTzuAMn7biLpclfC8dPEQ5yMjwx6WIhyom4TFibA0eUV8YEVWivxKqAt5JzJu6kcehIAehDPv2t5j94z2WRojl0eyBK64/lbLbedYJwhOkY4bO3AAblm1OSKgDkS/vT3JoCrouzUftABVhilFEiWVTFgZH7OAKhgixj/6wIO4ZHHrRSc+9OCDVkAXHjhwl+vsQqHoAcQwoA5vJxeA2pklB6FIrk7uQHq2rS3hQC7jeZTxiTUxdSCTL4yOgkwCB1KY7YkeS9QaFkIvK58h4GXcMtQP4wP39xKOM4k3Wm78ievoQWDJevfg5nTib74LB4/t2WM5OGIJXSZjpkgq2dHuEdJQX6fde2DITl1atLOX5v1aCTA6CHVTtPHA0SNYdUBAxBOIv8LlpaVlWyY83r1jFwCixzGSAmAbuQiF0M6lcKwHGAQTSrgrw+WgClhYXD5ujElsY9IT6wWr014V9fTqKz+0adRNGEP7tX/4a+723ajXcMeAVb5TGah2dGMnwK5h1eX6rCPuMTg1Fg3jbuHz4pqV4NLl1QLiWYSzoiTGC3bqzBnbTm7WxbdRxVMYtDxcJZeqAtfJQF68eNH64ehZXKxVDKDUQ7IjiYHr89C2Sk5BEyyVIDUTw72TboU/HeAy1yvoYnSJLw3VyKpVMIaXJi/YGz/+ka0zuY8/8ggqZ9sNc+1tA1YiFggYUbiO+SwShQ3tGCW71e1egYBV/jSN91BnUOtwR7VWsoWVdUAjVei6E+AwbrMzs5YAqHW4L7NeIhU4ZB0xUoQDA64GpoiiBO48EpBFNSTgOgUMC4ixVI1WGCJMXpLkTxbPowDIg+J2uFV/8nFVlKqUCtCpJEkThweIzztkkXibdUHvjXKr2r1pYAVeDWLLGCQlWqriPABpCDCMBx6MpUjKjJLRujI7b0uA3Nk+aIPE6LidcNCKzQNMyAbhIjgGMZX7pRg/BgfFMEL9JG3EbR2dadyzFPF+xQZw8LVKUaS/NManm8Bg5+7dNgRAe/kVF4+Pn8MIwa0YqzESO1IVcqVicKvUhVxDBwsa5a7JmEo7qETCJHfSSfvlf/Ci7d59t+3bt9/tQHD3+r9vajFRRKzBSdNzaxYuZDFM+IIko2cwIAszrHmBnELZFbipB59T7tY6BkXqIQpgqY6qbd9OQiRcQTd2EyAM+2qsdGCYOvAOItxuO8grDPC8VgUSqA+BMEEQoISLgFMRVzrzCSRmU9xeUhJd97nWjh6V+sngO2uSwtRvA2jQ8pXgfqSpjVTiDAZ2ipRkf1+/kUezpz//Bduzc89NgSq6bopjJTKrqzk7dXrW+jPzdtdYj0XJWMnHPH36JAYmAU/gGbSTDMFf1VpXW19a/ZEID5MEz9v+/UVALOOzJgkQ3EajQ1iFIFEu3RhlcjrwM9N9g+4CKUtVhrMU2c1MXQkMEX3oT8BqOUhFPy7qApp2MquLGDB0LK5dGZFPIkUeHADwPFHeNOtxRp/g7GCX8wVbXFvGOMow7laTN1WuG1iBKfEPVAA8BAi78K9LixljFdtiXcvOLWtksMRdLXFTjoAT5x79Iuz4i3UA6oZjG/ibMc6XUQNN8eRXnCkwFuZnAbnuPqmeDULTJaKsAkCoB4p/bfy4nhS6ivpqfMS58p+r5IRrACjd73SgdpahdY2QNyFd2pO2NgxfDr83jxFdIqhY4p7akgcjdSLDer369hOBFaDSQatYdQ8dIZIRMuCG9Q50WiG62yqEhhq0WEc60nlHA24OOrgQgMvUYMjM5hfkrItTxHE45QxURCvy0kfR2cWLJLQvX3RgtPalJZ9qpeQNQZY/H8yYjoWBLvLhn08OEyRgJD1aiCQ74YyhSRPA0rYJLBWRs4U5r1XLViMK7CHaKzO+CxNXfBJTyQ7rJQ060NeL2mu/LvXwicDm8A9nZuZsCR2ZYRalpyRqWhUoM7OSIenOUKiOY77qnOfjw1HXAD9cXHS5CIaOu+pqH4KeF7Auktwv5FmBYFmnJSHiOgEn4yPnXw6/F55XW7onLt2YS50Dlrfp7dIHUVUBf7hEFk50KCRO0latXrEs3BvOxwA64npZ3kOeMFcTvsY4y40VdHOHT25nijxHi9CAik3fHwmsCJXTPUFUs7KadePiC4axQMQkppdOv88SswYIT2gg/MmyX4uorgdFQw6OXYgZrOoH8KpGcCzpmMHVunp12l0j3dEKgaIqOvEB7dixw3bgxiXiSIc3GXCl6ga9KEeAIcRvVW62QQK8A32fZ+mmkMefhiv13DJSIfdK25sSGEt5MTXEvo988fDQiK82y6BqJURbnULUVWRYZp2uv6/HJ019blU+ElhFLudxXfKFMn5ojw9IyxstnDTDMBocy5cPDrgCbIJTbrUAFIQ6kwvmlfWcl+BAc4EC8D6U5jt56gz+6LJzpTgjmABa0GTAhcqAab1rcLCP5vCZIao1gUEXtOtNc8YzQS6YJXS4U8fyj1Vc9dC+EkACNobRlQqSnz3Y3+fSp/41qTKoGr9C81XcRHF6B8HPR5UtgRWR4prllQxx+3ZPr0Ffk/gADCWHZaWlD1Vflta5Nbjt/SkgKBFF6b5AVpJEmSedCwB4ygnOI5q+CIifKe7YvfeAHbm/y10zPdNJNipLZOV6nCflPmnloVgkvgfYViyvvQ2tvgJgNaVMmQwdnkmEAKMNt7CRCCZDS/W6p7HEMWARd+mqbnx9g4eoZuA6rtdFa50okdURDNkiIbX8ZKnBrcqWwGpp5SLr7x2snkrHKAhwgjX7Yi+A6cBh379jDMWPFQeMNGGrMkuqV2RW69TNoHOV7NaKqYpyo334pQLRCQbIIuDPTE95xkkD2NXdY6O4OUkMhtSCLHs/8f/M1LSHp0mMR5EAZIGViiybMAS2crtROKvEKoTURpj0oKZOvQrYCqGpJmOVhEwBd22YXG0ftNQJkcXaSdbaUim8AtpJkL8Yoj+1x1CI4CIuaVItWnkuFIPtSVIJWqVIp7s0tE1lywDhIk74KfZc9fUPMZMSH82Y9GcArPggiTVPwgUNRKcOsIrT4wBTWF6zGQZWhzMrTJCSIA4rXzF0YjuAiWKJmKKtOtZXeViJuIBtV6YL/1X3lQm7NHHRzp8/S5ar1+5lW6dCTE2kUoPBzhiccSZUml2bOBQFqi25WTqukX4ssPSzvLzoOYUZApjHHn7ADnR18wySBN3aV9ZGNNcGcyS7UlaaZkF0904LoaOT7XHaoR5jn0M9FaBJPrV0cxkbdNddezeBqgubOFZW+DJbdZSwUG4yHFbcE+jWDZ0EF6UBadv+feSJ2fbjHCg3SRCiC5bZCyCg0V1cBMhApPDTnAtCEFbC4s6xM1EcJu0hkVYRx4sGFU3mxfPn7Uc/es1ThrQCsClvoz3BsjqrEko1Kjjw5/hVirCHMLd/YJuDIW9C/qc60WQlSJAPpLqsC4AicHsjSjCCbx3Os7DJZFVRgdXpOSuxHSnG/j55QXpYY5eXIFUVom+tKC8QXWqrlNTbh8smYHPoO6X2UnQuHSliNPsaPCf8Mlt4hLF4h4euSgsrjRdBJTCNVkVflSA4ii4SZwfcGhAmjEWkjMXS8pK9/ur/RbwKjr0mR/d8aqjofxoMkVA61Y50lOz9t98kHEbnEkKLi+aW2EZE8kbNikvVm5a5Dx+5n2Vw8qzQomsKk6XWtN8gjcWPUDeLi9VNO0m8hRC+bIiJjQBadnHFispFZPLGHiURHBQI08boKKohyGuABBK7vLyCatneqrXxuwlYrRtJBKttGijOOCJfY9ZboAjYGg3WI51WxCWSPhbHxEhiQ7llmYQijnaUVQMVmS2+/HnneBrSQFcJG+cXZpnAFKom2GVYJEul6lpOiQKC+uzAZ9y3Z4AMv8Qcix6rARiiHumxSrjDumFucYykSx1JX2v9q1RmuYfJdoMHfZ6nkLhTpwF9K3UWG9G1nemUqzJJURiOXMKIrRF210nyNPiICEkD/1wyG/jbUjEFjLLcNOnurcomYLVjT60ockGwrI6yhiUDZGhBnFRn+2CRbZfhdIcVCRrkL9YQjQbALi0sIS4BCBsdNoHVuaywiM2QIND2y8cefcgNWBJwtK3I18TQy9KbCiO1XLKtj8HOXXTdls1VbI5J6xvuhXuT7ptCkYTF9akyYDJWZYCVHmx5Et63Zo1Pg/5rqIeM3CYSR7GmQRaABeWIdU4bYgpFioFfqWgOhkOtyTiuZZFbmGjm6oztP7Bfzf9M2QTsWz85Dpf0ukWWyLQ4QYZLRVwnsdPOvdDIoEU0lVzTnlSpjDyhb4VRwtROWPAMVajmBWB9AIhshmhu/PQp3+QmEKQPJQECRgBo6UZ7FErZDqz5is0ssv+gzF4w9sV2TGvPq95bCJx90aculNBO4LFoXSvGfelrp5wv/+VbgIVIwmjjXYpJ7GbtTM9q80cOnVkOBbCoHopu47kKnN4oI520m8mErIRXsDhz1Yf14a9NwM6zu693QIYo5A6zMu4qDmyTOBmVBkYAGfTcgJLF0r4RlLq2X5aqHIsc2vAfNeDRRHMSNBk6hMDLV6ZdZ2lgcuWUXNFD+i5gnDS05QwJlAqZMhlJyGmLB6sAOBTkZtu9tuh148S5OL0C4EVsAlzg96VrnRi+vTCRDS0eompCrE44vfRdGD9vhWowWarnz4lW2pckaqIUTiukL5CK1IborcomYGVBsxllderu9Cvx67wgIiUWnEUxTnnWhNpgwzC+n9aJGnBpHo5dxa3JQnQEQhwifjWk4Msfd45NoNMOHTwcuHAMSIR/8KEvPcyD4m5hrQFt2xFwTwCi6queflU9eF5AaF1sHX9V+7eavash7qjRoE0Z4jrALFdSFiUXG4VJZHSXF+ctj+SoxQBUR9VpkQejdmQjpNJqSJa2+m9VNgGrekVeushliTJK7NoDWLWqwbhLxG8YAt5l8a0dyx5iJVVeAT35Bt95aK/SqThYgAbPOYnejl9sXu/AR9S56jTRCW7D3W4wgpt8N42PFCl1AxBpxGsLLO9JF7iNcUVkMyvkMtUuJQCIX0mKn/sPRqxmJ8kdXGDpJoROr3J/jcmo8et0e+Um7TxaZ03MaeV6BK5VzrgtvfXrUZuATTBYuVyaGSWKA1XQmmv1FAB8SUk4vIdGCefer3KdcddRHcFwguHqCVUIyPMDvxR8fTDwFsHqSS6tdiLquQB09SCJCc51TT6zP60v3eZXh8E9Qe8nfkO3HdQmsLqla3qioGvsZdATalGc6M1JGrxAefM55Qzc+HI9QeAkLygiZ3eLsgnYsbH9hIsnWAkNxM8H1mzYj2nEN/VqYOKsZqNOmNdD33K9tWjXuh800QSDAWhozWYDwpvcFcDTGozD40OWROgxB076esMaOgxcDwjZCtgAxqCCQFJd9d0aj7frNNGGpJ2/FtDBGZX554aw2ZFsQYxErjZTb1W2APYuO/HmCV83aiAeUnDy29SRqPHMvTqhNZHKof/6ceuCrlPX/1TBi86uwYNjv6V6XjeoFdCthigtBNQSlXUagMGEcqEFjD/jdYP7fl11+VOvTjv3N85pS3PjXagbxujENNugohf1qQn0X768T9WlQrQKdKEE+333BJU/9L0J2MHBIWYiguOrt1dYt8IDGMSx1q6+OH7jEmtYxEoM6oPBqqMmTN58IMUBIQF4usy53w1q61ttuIfhRF9zk4oBaHpG7dC+GhU4GwAFddSzd9963OsEJwJSz6jChrfhKLVwVHu6zZeDGPyoii4H16BRF3SfL6lGTYRcQtGfJuewVdkEbHd3H2v3g2SCeAeAZRACL9vZNsCWSHKfuFOvKwOP2+F+qgj4gIKN9p0DnRBIcdCCEx2r6JHmFcdLRjGA3RvzOq0vvw6w/sttgRUAFrQTcGfzudZ9ndLBBudCZCulCRZenI9VXwNo1teNhjOMeqCi6jbvOencC7OMpJBW76N1ko/t5u2grcomYOWjHbnvATt/btxnRVmCc8sL9sxDj1odw1aaGMdXLfhbJ60GNXMkDvw0AIhTLgU0caUJbgtYVVQ95+wt7vlgm3WajQZjVINeGDjHDrEfONQu3npWlDShcZsXXJNvvvG0E+f0tS426XWiVU2g6qt1X/RyRRMUrrN8gxu/d98Bd+1U88NlE7Ai4vDh++21V1+xy+RkMYQ2gfU/ceakDZPxyZNjrSAOLCfS7wecJPdKxQFzopx2viRKXEdPC22/pedA1Q2c7jXBbRHXAlatfXC8cdfb3ABVEPrgVVc4cI6oOrw6VgqB4tebwDav+E+T1A08N+rpBrTrHPI2is6Vx9DS/sGD9/j9jZvXHGyZj5X1O378DftPf/YnJJPZs8oDcWYqSdJhlVCx7hEN4TT1BJjvXhHYuGfa++TBgQYHEeKeDbCbwIpQPSeXyo8DuFVRUPLXArT5KwJag6NNRuw0Ba5PcMxF+gsAVAQWHNO7OtAj/tWcZNFB32IaZdq0q1wGWrljPautosrVfvCcug9o0YjS3Z281/a8PfPMcxurF+rh2rKJY3VTjR858oA9eeycvfL975GxL1uRjteC5n2QWqNfywTvqEp9KNopVwqeCVMuVgbQE+Nq0Aemg2ZxADU4jVvgto45V12u62uDe9SArvEjGIPrrftB47rmDfKrIMGB1QNOs/+4hEhKWmtY2q6vlz8ivNIv57/EUo/Wtro6k+QpgnyH99hqGubpZCP12L699sgjxz4SVHrbnOjWRRXtZX32+V92bvw/3/sunEs6keUIt5DMWqyrzyZ+eoqVzQ4Gwf8lwHbNRBtLLSQmtJtQuVBfAXXODdoMeCsAUQPXuJkv9wwC7g3QC3QxwDmIqqfK0m9cob1AmwtAfQLMvYJmyq+J3zjWP/+oT3ErXEqCQZk7xf1F0oTaH1ZtlFm8nCfSZMsTSZwjDx0lqc22UDoSN4tOpSBT7TE7cNcBe/HFL5NwD3b2eL9bfG2pClr1RIzeNrl46YK989ZxO3v2NMHDPLdD9v45XrpgO5HynCn2n+o/fVhYXeIdVt6hghBtGlZ2Kk3CWaKlgXoyHL3Frkwn1pd84BQPOABAyW4YhnstEKSXFe0oZcdl2tWyiBATOOpb0iXVpaLkt4rqaVIcTK75Eg31VU/HWhXQe7jK/+plviTrXW8df5NrJG7Ie9x95F7bO8oW0jaFrbhX9JlmQfPJY0/Zo48dY5uoNvIF0+sdbvG1pSpo1RNHaK390OEjbBze68sQWlWY5x2q3/03/zYQLfw5uR/7Dh6y2ddedQ7R6q06fuSRx+23fuu3uYY+lUJjwPp4aMihcxB5htZio3IONYV8ACuOKiOaqiNLrPSgpEXDkbhWocMnhgaVg/WdL8T+6ktECEC1KzB9wpgMda82/td3vmNnx8f9usL3BmlCqTONTb9Krvyzf/mv2c3d4+1q5UFS2MWuR63QutqhrY8rHwts60GJgwDWRznXM/yXIsusvsbRpZp9zfLk3BRcqh2BZN0ZnBYi//E/+Ybt2r07aEbMpJFRAlFvHjNg/ROXMebgq3kc1AseDHRx0IS43+sGTWy09zPt/mwFdbHRh/Zq/dEf/Qd2IK6RKM9ZknhfdkHMIHUj8OKowlF2i4vkQOU0iW/2+Uk/1wXstY2IAyYBdpUNvupQg9HrO1WyXRJNJZ87iNBeeOF5u/fee72OP38NXdcz49f2ebuPX/rSL9l3vvNdVqLfRyqKrJHdY8u4kXpfQlKgdxD0btnde/c6B99M/x+vKLZoURx7eRL/ll9tNBOw20e2875BF6CyCopu3c8b1l//+tdvmqgtur2tl7SE/qWXXvIldb0dWUbpi8EVXotxciwRTU5Ouhq42Y5vGFgBmcuy+U2JW8kvZY33rMqstrbhNI+MDNk3fv03CPV6bpamO/6cJOb5F1/klc8dLvZTkxPsU8vSb1MnA/AEexnERDdbbhhY6aFR/kMFiYz0kbYW6W0Y7VrRfzXy8IMP2+NPPPGBCrhZyu7wc3qr/IvPftF62JcWj5FbhWNluJSs0UfLO7dSbhhYKfmRXXsghk1mdJ7Cn2vgx8ZRAduHttlX/9HXPtZxvhVib+ez4toXXvgl3mkYYBePNsXxqhNZPDFKlP1d/f2f7FJ9HD03bLxEUCdL3Z3oVHGtbwzDHeqBAz7/zOd5h3X04/r7VN0T1z711OfIi7zm+7caCm1rrAjgGvawpemTfNWPG8xNAdvLO/87RkfwLSu+w1k7pEdHRu2551761KuAa8EQkzz37Av2k+NvOZCdnRU2Yuh/SjKA7rylsdwwsHKpjrI57Vu//01/H1V6NsxMa7+q/qegv2tlcNuQPfjowxZmOV9BhxL6MsLb2Ht7Kxz7sSHt3zWQPk303rDx+jQR/2mm5TNg79DsfAbsZ8DeIQTuULN/C9qeVKzoytXKAAAAAElFTkSuQmCC"

    let machines = arr.map((obj, i) => {
      let x = Math.round(i/20);
      return {id: i, name: `Machine${i}`, pointArray: pointArray, pointLocationArray: pointLocationArray, buildingId: x, machineType: this.getMachineType(0, 2), machinePic: imageData, templateId: i};
    });

    this.storage.set('machines', JSON.stringify(machines));
  }


}
