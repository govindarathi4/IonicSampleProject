import { Injectable, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthProvider {
   @ViewChild('myNav') nav: NavController

  AUTH_USER = 'Athena.API';
  AUTH_PASS = 'fH49exyLcg4mmHXY';
  IMS_HOST = 'https://api.digitalvault.cloud/Identity/ims';
  //IMS_HOST = 'https://api.digitalvault.cloud/IDM/ims';
  
  constructor(public http: Http, public storage: Storage) {
  }

  encodeAuth() {
    return btoa(`${this.AUTH_USER}:${this.AUTH_PASS}`);
  }

  createHeaders(headers: Headers) {
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    headers.append('Authorization', `Basic ${this.encodeAuth()}`);
  }

  getHeaders() {
    let headers = new Headers();
    this.createHeaders(headers);
    return headers;
  }

  callLoginApi(username, password): Observable<any> {
    let headers = this.getHeaders();
    let options = new RequestOptions({ headers: headers });
    let body = {
      grant_type: 'password',
      scope: 'read write securityapi_all',
      username: username,
      password: password
    };

    let httpMethod = this.http.post(`${this.IMS_HOST}/connect/token`, `${this.serializeParams(body)}`, options);

    return httpMethod
        .map((response: Response) => {
          return response.json();
        })
        .catch((error: Response ) => {
          return error.json();
        });
  }

  logout() {
    this.storage.remove('authToken');
  }

  handleError(error) {
    console.log(error);
  }

  storeAuthToken(token) {
    this.storage.set('authToken', token);
  }

  retrieveAuthToken(){
    return this.storage.get('authToken').then((result) => {
      return result;
    });
  }

  serializeParams(obj) {
    var str = [];
    for (var p in obj)
      if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
      }
    return str.join("&");
  }

  validateToken(token) {

    let httpMethod = this.http.get(`${this.IMS_HOST}/connect/accesstokenvalidation?token=${token}`);

    return httpMethod
        .map((response: Response) => {
          return response.json();
        })
        .catch((error: Response ) => {
          return error.json();
        });
  }

}
