import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'searchListFilter'
})

export class SearchListFilter implements PipeTransform{
    
    transform(array, prop:string, queryString:String){
        if(queryString){
            var newArray = array.filter((item) => {
                return item[prop].toLowerCase().indexOf(queryString.toLowerCase()) != -1;
            });
        }
        return newArray || array;
    }
}