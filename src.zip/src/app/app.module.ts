import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { IonicStorageModule } from '@ionic/storage';
import { HttpModule } from '@angular/http';
import { Camera } from '@ionic-native/camera';
import { MyApp } from './app.component';

import { HomePage } from '../pages/home/home';
import { DevicePage } from '../pages/device/device';
import { LoginPage } from '../pages/login/login';
import { NewMachinePage } from '../pages/new-machine/new-machine';
import { Settings } from '../pages/settings/settings';
import { JobDetail } from '../pages/job-detail/job-detail';
import { JobList } from '../pages/job-list/job-list';
import { MachineLanding } from '../pages/machineLanding/machineLanding';
import { AddJob } from '../pages/add-job/add-job';
import { NewMachineTemplate } from '../pages/new-machine-template/new-machine-template';
import { FindMachine } from '../pages/find-machine/find-machine';
import { PreRecordingPage } from '../pages/pre-recording/pre-recording';
import { CreateObservationPage } from '../pages/create-observation/create-observation';
import { CreateNotePage } from '../pages/create-note/create-note';
import { RecordingPage } from '../pages/recording/recording';

import { ProgressBar } from '../components/progress-bar/progress-bar';
import { JobRow } from '../components/job-row/job-row';
import { JobCard } from '../components/cards/job-card/job-card.component';
import { MachineCard } from '../components/cards/machine-card/machine-card.component';

import { AuthProvider } from '../providers/authProvider';
import { DataStore } from '../providers/data-store';

import { Geolocation } from '@ionic-native/geolocation';

import { BranchService } from './services/branch.service';
import { JobService } from './services/job.service';
import { MachineService } from './services/machine.service';
import { BuildingService } from './services/building.service';
import { TemplateService } from './services/template.service';
import { CustomerService } from './services/customer.service';
import { UserService } from './services/user.service';
import { RecordingService } from './services/recording.service';

import { SearchListFilter } from '../pipes/search-list-filter.pipe';

import { RequestMethodsService } from '../commons/request-methods-service';
import { Constants } from '../commons/constants';

@NgModule({
  declarations: [
    AddJob,
    DevicePage,
    FindMachine,
    HomePage,
    JobDetail,
    JobList,
    JobRow,
    LoginPage,
    MachineLanding,
    MyApp,
    NewMachinePage,
    NewMachineTemplate,
    ProgressBar,
    Settings,
    PreRecordingPage,
    CreateObservationPage,
    CreateNotePage,
    RecordingPage,
    SearchListFilter,
    JobCard,
    MachineCard
    // Geolocation
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    AddJob,
    DevicePage,
    FindMachine,
    JobDetail,
    JobList,
    HomePage,
    LoginPage,
    MachineLanding,
    MyApp,
    NewMachinePage,
    CreateObservationPage,
    CreateNotePage,
    PreRecordingPage,
    RecordingPage,
    NewMachineTemplate,
    Settings
  ],
  providers: [
    Storage,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthProvider,
    Camera,
    DataStore,
    Geolocation,
    BranchService,
    JobService,
    MachineService,
    TemplateService,
    BuildingService,
    CustomerService,
    RecordingService,
    UserService,
    RequestMethodsService,
    Constants
  ]
})
export class AppModule {}
