import { Injectable, isDevMode } from '@angular/core';
import { HardwareBle } from '../models/hardware-ble';
import { SoftwareBle } from '../models/software-ble';
import { BLEable } from '../models/bleable';

@Injectable()
export class BleService {

  ble: BLEable;

  constructor() {
    this.ble = isDevMode() ? new SoftwareBle() : new HardwareBle();
    // this.ble = new HardwareBle();
    // this.ble = new SoftwareBle();
  }

  getBle() {
    return this.ble;
  }

  writeChar(serial){
    var result = this.ble.writeChar("72B40B43-7B8C-41A8-AF31-B547AD292B97", "true")
    return(result);
  }
}
