import { Injectable, Component } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Machine } from '../models/machine';


@Injectable()
export class MachineService {

  machines: Machine[] = [];

  constructor(private dataStore: DataStore){

  }

  initializeMachines(){
    return this.dataStore.getMachines().then((data) => {
      return this.parseMachines(JSON.parse(data));
    });
  }

  addMachine(machine) {
    machine.machineSerial = this.machines.length
    this.machines.push(machine);
    console.log(this.machines);
  }

  parseMachines(passedMachines) {
    passedMachines.map((machine) => {
      if(!this.checkIfMachine(machine.id)){
        let instance = new Machine(machine.name, machine.id, machine.pointArray, machine.pointLocationArray, machine.buildingId, machine.machineType, machine.machinePic, machine.templateId, machine.jciAssetId, machine.modelNumber, machine.sN, machine.criticality, machine.machineDutyType, machine.starterType, machine.starterIncomingLineFrequency, machine.electricMotorMake, machine.electricMotorModel, machine.electricMotorVolts, machine.electricMotorHp, machine.electricMotorFrame, machine.nonDriveEndBallBearingOem, machine.nonDriveEndBallBearingBearingNumber, machine.driveEndBallBearingOem, machine.driveEndBallBearingBearingNumber, machine.base64Image, machine.refrigerantModel, machine.refrigerantSn, machine.refrigerantHotGasBypass, machine.gearSetSpeedCode);
        this.machines.push(instance);
      }
    });
  }

  getMachinesByJob(idArray){
    let machines = [];
    this.machines.filter((machine) => {
      if(idArray.indexOf(String(machine.machineSerial)) > -1){
        machines.push(machine);
      }
    });
    return machines;
  }

  getMachinesByBuilding(buildingId){
    let buildingMachines = [];
    this.machines.map((machine) => {
      console.log("Passed buildingId", buildingId, typeof buildingId);
      console.log("Itterated buildingId", machine.buildingId, typeof machine.buildingId);
      if(machine.buildingId.toString() === buildingId) {

        buildingMachines.push(machine);
        console.log("Building Machines Match", buildingMachines);
      }
    });
    return buildingMachines;
  }

  checkIfMachine(machineSerial){
    let machines = this.machines.filter((machine) => {
      return machine.machineSerial === machineSerial;
    })
    if (machines.length > 0){
      return true;
    } else {
      return false;
    };
  }

  addNote(machineSerial, tempNote){
    // console.log("In Add Observation", this.recordings);
    console.log("In Add Note", tempNote);

    this.machines.forEach((machine) => {
      // console.log(recording.recordingId, "id of itterated recording");
      // console.log(recordingId, "passed In Id");
      if (machine.machineSerial == machineSerial){
        machine.addRepairNote(tempNote);
        // console.log("In Add Observation", recording.observationArray);
      }
    });
  }

  getNotes(machineSerial){
    let notes = [];
    this.machines.forEach((machine) => {
      // console.log("The For Each Recording", typeof recording.recordingId);
      // console.log("The passed in recording", typeof recordingId);
      if (machine.machineSerial == machineSerial){
        // console.log("Match in Get Observations", recording.observationArray);
        notes = machine.noteArray;
      }
    });
    console.log("Being passed back", notes);
    return notes;
  }


}
