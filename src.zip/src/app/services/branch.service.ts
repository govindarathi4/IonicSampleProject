import { Injectable, Component } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Branch } from '../models/branch';

@Injectable()
export class BranchService {

  branches: Branch[] = [];
  preferredBranch: string;

  constructor(private dataStore: DataStore){

  }

  initializeBranches() {
      this.dataStore.getPreferredBranch().then((data) => {
        this.preferredBranch = data;
      });

      return this.dataStore.getBranches().then((data) => {
        return this.parseBranches(JSON.parse(data));
      });
  }

  parseBranches(passedBranches) {
    this.branches = [];
    passedBranches.map((branch) => {
      let instance = new Branch(branch.id.toString(), branch.branchName, branch.location, branch.buildingIdArray );
      this.branches.push(instance);
    });
  }

  getBranchById(branchId) {
    return this.branches.filter((instance) => {
      return instance.branchId == branchId;
    })[0];
  }

  getBranches() {
    return this.branches;
  }

  getDefaultBranch(){
    if(this.branches.length > 0){
      return this.branches[0].branchName;
    } else {
      return "No Branches"
    }
  }

  getPreferredBranch() {
    return this.preferredBranch;
  }

  // setDefaultPreferredBranch(){
  //   console.log("setting preferred Branch to first option");
  //   this.preferredBranch = this.branches[0].branchId;
  //   this.dataStore.setPreferredBranch(this.branches[0].branchId);
  // }

  setPreferredBranch(branchId) {
    this.preferredBranch = branchId;
    this.dataStore.setPreferredBranch(branchId);
  }
}
