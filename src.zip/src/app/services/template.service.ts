import { Injectable, Component } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Template } from '../models/template';


@Injectable()
export class TemplateService {

    templates: Template[] = [];

    constructor(private dataStore: DataStore){

    }

    initializeTemplates(){
      return this.dataStore.getTemplates().then((data) => {
        return this.parseTemplates(JSON.parse(data));
      });
    }

    parseTemplates(passedTemplates) {
      passedTemplates.map((template) => {
        let instance = new Template(template.id, template.make, template.model, template.machineType, template.intermediaryType, template.drivenType, template.driveType, template.motorOrientation, template.drivenBearings, template.drivenSupportStyle, template.cooled, template.templateName, template.hasMotor);

        this.templates.push(instance);
      });
    }
}
