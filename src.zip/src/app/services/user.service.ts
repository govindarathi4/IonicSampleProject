import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { DataStore } from '../../providers/data-store';
import { BranchService } from './branch.service';

@Injectable()
export class UserService {

  currentUser: User;
  users: User[] = [];

  constructor(private dataStore: DataStore, private branchService: BranchService){

  }

  initializeUsersFromDatabase(){
    return this.dataStore.getUsers().then((data) => {
      return this.parseUsers(JSON.parse(data));
    })
  }

  parseUsers(passedUsers){
    passedUsers.map((user) => {
      let instance = new User(user.userId.toString(), user.primaryBranch.toString(), user.userName.toString() );
      this.users.push(instance);
    });
  }

  findOrCreateUser(userName){
    let foundUser = false;
    this.users.forEach((user) =>{
      if(user.userName == userName){
        this.currentUser = user;
        foundUser = true;
        // if (this.currentUser.primaryBranch = "No Branches"){
        //   this.branchService.setDefaultPreferredBranch();
        // }
      }
    })
    if (!foundUser){
      this.currentUser = new User(this.createUserId(), this.branchService.getDefaultBranch(), userName);
      console.log(this.currentUser);
      this.users.push(this.currentUser);
      this.dataStore.setUsers(this.users);
    }
  }

  setUser(){

  }

  getUser(){
    console.log("In Get User", this.currentUser);
    return this.currentUser;
  }

  checkIfUser(userId){

  }

  createUserId(){
    let highestId = -1;
    this.users.forEach((user)=>{
      if(highestId < parseInt(user.userId)){
        highestId = parseInt(user.userId);
      }
    })
    return highestId+1;
  }
}
