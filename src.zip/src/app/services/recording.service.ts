import { Injectable } from '@angular/core';
import { Observation } from '../models/observation';
import { DataStore } from '../../providers/data-store';
import { Recording } from '../models/recording';

@Injectable()
export class RecordingService {

  recordings: Recording[] = [];

  constructor(private dataStore: DataStore){

  }

  initializeRecordings(){
    return this.dataStore.getRecordings().then((data) => {
      return this.parseRecordings(JSON.parse(data));
    })
  }

  parseRecordings(passedRecordings){
    passedRecordings.map((recording) => {
      let instance = new Recording(recording.recordingId, recording.dateStarted, recording.machineName, recording.machineId, recording.status);
      this.recordings.push(instance)
    });
  }

  createRecordingId(){
    let highestId = -1;
    this.recordings.forEach((recording) => {
      if (highestId < parseInt(recording.recordingId)){
        highestId = parseInt(recording.recordingId);
      }
    })
    return highestId+1;
  }

  addRecording(recording){
    console.log("Adding Recording");
    this.recordings.push(recording);
  }

  addObservation(recordingId, tempObservation){
    // console.log("In Add Observation", this.recordings);
    console.log("In Add Observation", tempObservation);

    this.recordings.forEach((recording) => {
      // console.log(recording.recordingId, "id of itterated recording");
      // console.log(recordingId, "passed In Id");
      if (recording.recordingId == recordingId){
        recording.observationArray.push(tempObservation);
        // console.log("In Add Observation", recording.observationArray);
      }
    });
  }

  getObservations(recordingId){
    let observations = [];
    this.recordings.forEach((recording) => {
      // console.log("The For Each Recording", typeof recording.recordingId);
      // console.log("The passed in recording", typeof recordingId);
      if (recording.recordingId == recordingId){
        // console.log("Match in Get Observations", recording.observationArray);
        observations = recording.observationArray;
      }
    });
    console.log("Being passed back", observations);
    return observations;
  }
}
