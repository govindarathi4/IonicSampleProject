import { Injectable } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Building } from '../models/building';

@Injectable()
export class BuildingService {

  buildings: Building[] = [];

  constructor(private dataStore: DataStore) {

  }

  initializeBuildings() {
    this.dataStore.getBuildings().then((data) => {
      return this.parseBuildings(JSON.parse(data));
    })
  }

  parseBuildings(passedBuildings) {
    this.buildings = [];
    passedBuildings.map((building) => {
      let instance = new Building(building.id, building.name, building.location, building.customerId, building.coordinates);
      this.buildings.push(instance);
    });
  }

  getBranchBuildings(buildingIdArray){
    let buildings = [];
    this.buildings.map((building) => {
      if(buildingIdArray.indexOf(String(building.buildingId)) > -1) {
        buildings.push(building);
      }
    });
    // console.log(buildings)
    return buildings;
  }

  getBuildingByID(buildingId){
    let soughtBuilding;
    this.buildings.forEach((building) => {
      if (building.buildingId.toString() == buildingId){

        soughtBuilding = building;
      }
    });
    return soughtBuilding;
  }

  getCustomerByBuildingID(buildingId){
    let soughtBuilding;
    this.buildings.forEach((building) => {
      if (building.buildingId.toString() == buildingId){

        soughtBuilding = building;
      }
    });
    return soughtBuilding.customerId;
  }

  // getBuildingByName(name){
  //   return this.buildings.filter((building) => {
  //     return building.name = name;
  //   })
  // }
}
