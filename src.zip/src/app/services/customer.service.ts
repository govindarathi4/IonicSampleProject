import { Injectable, Component } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Customer } from '../models/customer';

@Injectable()
export class CustomerService {

  customers: Customer[] = [];

  constructor(private dataStore: DataStore){

  }

  initializeCustomers(){
    this.dataStore.getCustomers().then((data) => {
      return this.parseCustomers(JSON.parse(data));
    })
  }

  parseCustomers(passedCustomers){
    this.customers = [];
    passedCustomers.map((customer) => {
      let instance = new Customer(customer.id, customer.name);
      this.customers.push(instance);
    });
  }

  getCustomerById(customerId){
    let soughtCustomer;
    this.customers.forEach((customer) => {
      if(customer.customerId.toString() == customerId){
        soughtCustomer = customer;
      }
    });
    return soughtCustomer;
  }
}
