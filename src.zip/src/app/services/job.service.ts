import { Injectable, Component } from '@angular/core';
import { DataStore } from '../../providers/data-store';
import { Job } from '../models/job';


@Injectable()
export class JobService {

    jobs: Job[] = [];
    jobIds: string[] = [];
    needSave: Boolean = false;

    constructor(private dataStore: DataStore){

    }

    initializeJobs(){
      return this.dataStore.getJobs().then((data) => {
        return this.parseJobs(JSON.parse(data));
      });
    }

    parseJobs(passedJobs) {

      this.jobs = [];
      passedJobs.map((job) => {
        console.log("In Parse Jobs", job);
        let instance = new Job(job.jobId, job.jobName, job.buildingId, job.machineIdArray, job.jobStatus, job.recordings);

        this.jobs.push(instance);
        this.jobIds.push(job.id);
      });
    }

    getOpenJobs() {

      return this.jobs.filter((job) => {
        return job.jobStatus === "open";
      })
    }

    getClosedJobs() {
      return this.jobs.filter((job) => {
        return job.jobStatus === "closed";
      })
    }

    addJob(job){
      this.needSave = true;
      this.jobs.push(job);
      this.jobIds.push(job.id);
    }

    addMachinesToJob(machineList, jobId){
      this.jobs.forEach((job) => {
        if (job.jobId == jobId){
          machineList.forEach((machineId) => {
            job.machineIdArray.push(machineId.toString());
          });
        }
      });
    }

    getJobById(jobId){
      let soughtJob;
      this.jobs.forEach((job) => {
        if (job.jobId == jobId){
          soughtJob = job;
        }
      });
      return soughtJob;
    }

    createJobId(){
      let highestId = -1;
      this.jobs.forEach((job) => {
        if (highestId < parseInt(job.jobId)){
          highestId = parseInt(job.jobId);
        }
      })
      return highestId+1;
    }

    checkIfJob(jobId){
      let jobs = this.jobs.filter((job) => {
        return job.jobId === jobId;
      })
      if (jobs.length > 0){
        return true;
      } else {
        return false;
      };
    }

    saveJobs(){
      this.dataStore.setJobs(this.jobs);
    }

  }
