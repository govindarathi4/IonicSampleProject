import { Recording } from './recording';


export class Job {
  jobId: string;
  jobName: string;
  buildingId: string;
  machineIdArray: String[] = [];
  jobStatus: string;
  creationDate: Date;
  recordings: Recording[] = [];

  constructor(jobId, jobName, buildingId, machineIdArray, jobStatus, recordings){
    this.jobId = jobId;
    this.jobName = jobName;
    this.buildingId = buildingId;
    this.jobStatus = jobStatus;
    this.machineIdArray = machineIdArray;
    this.creationDate = new Date();
    this.recordings = recordings;
  }
}
