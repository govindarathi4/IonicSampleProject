import { Observation } from './observation';
import { RecordingData } from './recordingData';

export class Recording {
  recordingId: string;
  machineName: string;
  machineId: string;
  dateStarted: Date;
  observationArray: Observation[] = [];
  status: string;
  recordingDataArray: RecordingData[] = [];  


  constructor(recordingId, date, machineName, machineId, status){
    this.recordingId = recordingId;
    this.machineName = machineName;
    this.machineId = machineId;
    this.dateStarted = date;
    this.status = status;
  }
}
