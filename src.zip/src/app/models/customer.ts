export class Customer {
  customerId: string;
  name: string;

  constructor(customerId, name){
    this.customerId = customerId;
    this.name = name;
  }
}
