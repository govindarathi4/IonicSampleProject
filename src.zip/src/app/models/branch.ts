export class Branch {
  branchId: string;
  branchName: string;
  location: string;
  buildingIdArray: String[] = [];

  constructor(branchId, branchName, location, buildingIdArray){
    this.branchId = branchId;
    this.branchName = branchName;
    this.location = location;
    this.buildingIdArray = buildingIdArray;
  }
}
