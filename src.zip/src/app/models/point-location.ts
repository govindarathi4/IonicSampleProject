export class PointLocation {
  pointLocationId: string;
  pointLocationName: string;

  constructor(pointLocationId, pointLocationName){
    this.pointLocationId = pointLocationId;
    this.pointLocationName = pointLocationName;
  }
}
