import { Observable } from 'rxjs/observable';

export interface BLEable {
  scan: () => Observable<any>;
  connect: (uuid: string) => Observable<any>;
  disconnect: () => Promise<{}>;
  writeChar: (char_id: string, value: string) => Promise<{}>;
  writeBoolean: (char_id: string, value: boolean) => Promise<{}>;
}
