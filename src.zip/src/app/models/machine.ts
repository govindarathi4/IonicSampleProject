import { Point } from './point';
import { PointLocation } from './point-location';
import { Note } from './note';


export class Machine {
  machineSerial: string;
  machineName: string;
  pointArray: Point[] = [];
  pointLocationArray: PointLocation[] = [];
  noteArray: Note[] = [];
  buildingId: string;
  machineType: string;
  machinePic: string;
  templateId: string;
  jciAssetId: string;
  modelNumber: string;
  sN: string;
  criticality: string;
  machineDutyType: string;
  starterType: string;
  starterIncomingLineFrequency: string;
  electricMotorMake: string;
  electricMotorModel: string;
  electricMotorVolts: number;
  electricMotorHp: number;
  electricMotorFrame: string;
  nonDriveEndBallBearingOem: string;
  nonDriveEndBallBearingBearingNumber: string;
  driveEndBallBearingOem: string;
  driveEndBallBearingBearingNumber: string;
  base64Image: string;
  refrigerantModel: string;
  refrigerantSn: string;
  refrigerantHotGasBypass: string;
  gearSetSpeedCode:string;


  constructor(machineName, machineSerial, pointArray, pointLocationArray, buildingId, machineType, machinePic, templateId, jciAssetId, modelNumber, sN, criticality, machineDutyType, starterType, starterIncomingLineFrequency, electricMotorMake, electricMotorModel, electricMotorVolts, electricMotorHp, electricMotorFrame, nonDriveEndBallBearingOem, nonDriveEndBallBearingBearingNumber, driveEndBallBearingOem, driveEndBallBearingBearingNumber, base64Image, refrigerantModel, refrigerantSn, refrigerantHotGasBypass, gearSetSpeedCode){
    this.machineName = machineName;
    this.machineSerial = machineSerial;
    this.pointArray = pointArray;
    this.pointLocationArray = pointLocationArray;
    this.buildingId = buildingId;
    this.machineType = machineType;
    this.machinePic = machinePic;
    this.templateId = templateId;
    this.jciAssetId = jciAssetId;
    this.modelNumber = modelNumber;
    this.sN = sN;
    this.criticality = criticality;
    this.machineDutyType = machineDutyType;
    this.starterType = starterType;
    this.starterIncomingLineFrequency = starterIncomingLineFrequency;
    this.electricMotorMake = electricMotorMake;
    this.electricMotorModel = electricMotorModel;
    this.electricMotorVolts = electricMotorVolts;
    this.electricMotorHp = electricMotorHp;
    this.electricMotorFrame = electricMotorFrame;
    this.nonDriveEndBallBearingOem = nonDriveEndBallBearingOem;
    this.nonDriveEndBallBearingBearingNumber = nonDriveEndBallBearingBearingNumber;
    this.driveEndBallBearingOem = driveEndBallBearingOem;
    this.driveEndBallBearingBearingNumber = driveEndBallBearingBearingNumber;
    this.base64Image = base64Image;
    this.refrigerantModel = refrigerantModel;
    this.refrigerantSn = refrigerantSn;
    this.refrigerantHotGasBypass = refrigerantHotGasBypass;
    this.gearSetSpeedCode = gearSetSpeedCode;
  }

  addRepairNote(note){
    this.noteArray.push(note);
  }
}
