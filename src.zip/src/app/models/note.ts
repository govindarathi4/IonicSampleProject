export class Note {

  noteId: string;
  machineSerial: string;
  userName: string;
  userId: string;
  notePic: string;
  repairNote: string;
  noteCreationDate: Date;
  repairDate: Date;


  constructor(machineSerial, userName, userId){
    this.noteCreationDate = new Date();
    this.machineSerial = machineSerial;
    this.userName = userName;
    this.userId = userId;
  }

  addNotePic(takenPicture){
    this.notePic = takenPicture;
  }

  addNoteText(text){
    this.repairNote = text;
  }

  addRepairDate(date){
    this.repairDate = date;
  }

}
