export class RecordingData{

  dataId: string;

  constructor(dataId){
    this.dataId = dataId;
  }
}
