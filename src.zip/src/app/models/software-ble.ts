import { Injectable } from '@angular/core';
import { BLEable } from './bleable';
import * as Rx from "rxjs/Rx";
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';

@Injectable()
export class SoftwareBle implements BLEable {

  constructor() {
  }

  scan() {
    return this.streamSoon({
      "id":"B0FC2954-7756-48C7-B05C-6A78B3138981",
      "rssi":-53,
      "advertising":{
        "kCBAdvDataIsConnectable":true,
        "kCBAdvDataServiceUUIDs":["DE1769A1-57AC-423F-9E82-970D25656151"],
        "kCBAdvDataLocalName":"athena?"
      },
      "name":"athena?"
    });
  }

  connect(uuid: string) {
    return this.streamSoon({
      "characteristics":[{"properties":["Write"],"isNotifying":false,"characteristic":"072455EF-4F03-4CBB-B90C-E63B32E06C3A","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"230650DB-6B49-47E2-98E9-EBD07572DA3A","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"A9C243CC-0DA5-41F5-8972-C06D7CD4FF44","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"C58A4FAE-A455-4CCC-8B95-01B21762BC5B","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"55204E5B-E125-4D8C-9A05-121D83C86C59","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"DD995150-B389-45E8-80ED-85A9FD84B22C","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Write"],"isNotifying":false,"characteristic":"72B40B43-7B8C-41A8-AF31-B547AD292B97","service":"DE1769A1-57AC-423F-9E82-970D25656151"},{"properties":["Read"],"isNotifying":false,"characteristic":"81888C81-3300-48C5-8F6A-901BC7FAE052","service":"DE1769A1-57AC-423F-9E82-970D25656151"}],"id":"D91594A9-698B-48F8-88F9-84EBFAE83211","rssi":-58,"advertising":{"kCBAdvDataIsConnectable":true,"kCBAdvDataServiceUUIDs":["DE1769A1-57AC-423F-9E82-970D25656151"],"kCBAdvDataLocalName":"athena?"},"name":"athena?","services":["DE1769A1-57AC-423F-9E82-970D25656151"]});
  }

  disconnect() {
    return this.resolveSoon({ok: "ok"});
  }

  writeChar(char_id: string, value: string) {
    return this.resolveSoon({ok: "ok"});
  }

  writeBoolean(char_id: string, value: boolean) {
    return this.resolveSoon({ok: "ok"});
  }

  resolveSoon(json: object) {
    return new Promise<object>((resolve, reject) => {
      setTimeout(() => resolve(json), 1);
    });
  }

  streamSoon(json: object) {
    return Rx.Observable.create(observer => {
      setTimeout(() => observer.next(json), 1);
      setTimeout(() => observer.complete(), 60);
    });
  }
}
