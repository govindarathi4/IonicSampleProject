import { Machine } from './machine';

export class Observation {
  observationDate: Date;
  machineId: string;
  userName: string;
  userId: string;
  observationText: string;
  observationPic: string;

  constructor(machineId, userName, userId){
    this.observationDate = new Date();
    this.machineId = machineId;
    this.userName = userName;
    this.userId = userId;
  }

  addPicture(picture){
    this.observationPic = picture;
  }

  addText(text){
    this.observationText = text;
  }
}
