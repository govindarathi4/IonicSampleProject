export class User {
  userId: string;
  primaryBranch: string;
  userName: string;


  constructor(userId, primaryBranch, userName){
    this.userId = userId;
    this.primaryBranch = primaryBranch;
    this.userName = userName;
  }
}
