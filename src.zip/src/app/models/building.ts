export class Building {
  buildingId: string;
  name: string;
  location: string;
  coordinates = {};
  customerId: string;


  constructor(buildingId, name, location, customerId, coordinates){
    this.buildingId = buildingId;
    this.name = name;
    this.location = location;
    this.customerId = customerId;
    this.coordinates = coordinates;
  }
}
