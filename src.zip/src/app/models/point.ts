
export class Point {
  pointId: string;
  uploadPercent: number;

  constructor(pointId, uploadPercent){
    this.pointId = pointId;
    this.uploadPercent = uploadPercent;
  }
}
