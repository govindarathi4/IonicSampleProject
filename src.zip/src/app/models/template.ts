export class Template {
  id: string;
  make: string;
  model: string;
  machineType: string;
  intermediaryType: string;
  drivenType: string;
  driveType: string;
  motorOrientation: string;
  drivenBearings: number;
  drivenSupportStyle: string;
  cooled: string;
  templateName: string;
  hasMotor: string;

  constructor(id, make, model, machineType, intermediaryType, drivenType, driveType, motorOrientation, drivenBearings, drivenSupportStyle, cooled, templateName, hasMotor){
    this.id = id;
    this.make = make;
    this.model = model;
    this.machineType = machineType;
    this.intermediaryType = intermediaryType;
    this.drivenType = drivenType;
    this.driveType = driveType;
    this.motorOrientation = motorOrientation;
    this.drivenBearings = drivenBearings;
    this.drivenSupportStyle = drivenSupportStyle;
    this.cooled = cooled;
    this.templateName = templateName;
    this.hasMotor = hasMotor;
  }
}
