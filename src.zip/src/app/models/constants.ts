export class Constants {
  public static serviceId: string = "DE1769A1-57AC-423F-9E82-970D25656151";
  public static char_leds: string[] = [
    "A9C243CC-0DA5-41F5-8972-C06D7CD4FF44",
    "C58A4FAE-A455-4CCC-8B95-01B21762BC5B",
    "55204E5B-E125-4D8C-9A05-121D83C86C59",
    "DD995150-B389-45E8-80ED-85A9FD84B22C"
  ];
  public static isCollectingDataUUID: string = "72B40B43-7B8C-41A8-AF31-B547AD292B97";
}
