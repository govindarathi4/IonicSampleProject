import { BLEable } from './bleable';

import { AthenaService } from './athena_service';

import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';

export class BleScanner {
  ble: BLEable;

  constructor(ble: BLEable) {
    this.ble = ble;
  }

  findAthenaService() {
    return this.ble.scan().filter(device => {
      return AthenaService.isAthenaService(device);
    }).map(athena => {
      console.log("subscribe found an athena");
      console.log(JSON.stringify(athena));
      return new AthenaService(this.ble, athena);
    });
  }
}
