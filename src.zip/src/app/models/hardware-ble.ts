import { Injectable } from '@angular/core';

import { Maybe } from 'tsmonad';
import { BLE } from '@ionic-native/ble';
import { BLEable } from './bleable';
import { Constants } from './constants';

import 'rxjs/add/operator/share';

@Injectable()
export class HardwareBle implements BLEable {
  ble: BLE;
  connectedDeviceUUID: Maybe<string> = Maybe.nothing<string>();

  constructor() {
    this.ble = new BLE();
  }

  scan() {
    let devices = this.ble.scan([Constants.serviceId.toUpperCase()], 5);
    console.log(devices);
    return devices
  }

  connect(uuid: string) {
    let shareable = this.ble.connect(uuid).share();
    shareable.subscribe(connect => {
      this.connectedDeviceUUID = Maybe.just(uuid);
      return () => {};
    });
    return shareable;
  }

  disconnect() {
    return this.connectedDeviceUUID
      .caseOf({
        just: uuid => this.ble.disconnect(uuid),
        nothing: () => new Promise((resolve, reject) => resolve("ok"))
      });
  }

  writeChar(char_id: string, value: string) {
    console.log("writing a char in Ble to device " + (this.connectedDeviceUUID.valueOr("<?>")) + " and service " + Constants.serviceId + " and char id " + char_id + " with value " + value);

    let rejection = () => {
      console.log("uuid was not set");
      return {};
    };

    return this.connectedDeviceUUID
      .caseOf({
        just: uuid => this.ble.write(uuid, Constants.serviceId, char_id, this.stringToBytes(value)),
        nothing: () => new Promise((resolve) => resolve(rejection()))
      });
  }

  writeBoolean(char_id: string, value: boolean) {
    let rejection = () => {
      console.log("uuid was not set");
      return {};
    };

    return this.connectedDeviceUUID
      .caseOf({
        just: uuid => this.ble.write(uuid, Constants.serviceId, char_id, this.booleanToBytes(value)),
        nothing: () => new Promise((resolve) => resolve(rejection()))
      });
  }


  stringToBytes(str: string) {
   var array = new Uint8Array(str.length);
   for (var i = 0, l = str.length; i < l; i++) {
       array[i] = str.charCodeAt(i);
    }
    return array.buffer;
  }

  booleanToBytes(bool: boolean) {
    var array = new Uint8Array(1);
    array[0] = bool ? 1 : 0;
    return array.buffer;
  }
}
