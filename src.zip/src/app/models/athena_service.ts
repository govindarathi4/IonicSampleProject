import { BLEable } from './bleable';
import { Constants } from './constants';

export class AthenaService {
  metadata: Object;
  ble: BLEable;
  _connectionStatus: boolean = false;

  static isAthenaService(json: Object) {
    try {
      return json["advertising"]["kCBAdvDataServiceUUIDs"].
        map(x => x.toUpperCase()).
        includes(Constants.serviceId.toUpperCase());
    } catch (e) {
      return false;
    }
  }

  constructor(ble: BLEable, json: Object) {
    this.metadata = json;
    this.ble = ble;
  }

  connect(callback) {

    let obs = this.ble.connect(this.uuid());
    obs.subscribe(connection => {
      this._connectionStatus = true;
      callback(this);
    });
    return obs;
  }

  disconnect() {
    return this.ble.disconnect().catch(e => console.log("Error disconnecting: " + JSON.stringify(e)));
  }


  // toggleLed(led: number) {
  //   console.log('toggle led ' + led);
  //   return this.ble.writeChar(Constants.char_leds[led], "toggle");
  // }

  startCollecting() {
    return this.ble.writeBoolean(Constants.isCollectingDataUUID, true);
  }

  stopCollecting() {
    return this.ble.writeBoolean(Constants.isCollectingDataUUID, false);
  }

  // getters

  deviceName() {
    return this.metadata['name'];
  }

  uuid() {
    return this.metadata['id'];
  }

  connectionStatus() {
    return this._connectionStatus;
  }

}
