import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { App } from 'ionic-angular';

import { AppModule } from './app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
