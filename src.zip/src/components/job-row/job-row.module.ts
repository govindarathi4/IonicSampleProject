import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobRow } from './job-row';

@NgModule({
  declarations: [
    JobRow,
  ],
  imports: [
    IonicPageModule.forChild(JobRow),
  ],
  exports: [
    JobRow
  ]
})
export class JobRowModule {}
