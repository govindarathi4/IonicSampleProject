import { NavController, NavParams } from 'ionic-angular';
import { Component, Input } from '@angular/core';
import { Job } from  '../../app/models/job';
import { Customer } from '../../app/models/customer';
import { Machine } from '../../app/models/machine';
import { JobDetail } from '../../pages/job-detail/job-detail';
import { MachineLanding } from '../../pages/machineLanding/machineLanding';
import { MachineService } from '../../app/services/machine.service';
import { BuildingService } from '../../app/services/building.service';
import { CustomerService } from '../../app/services/customer.service';
// import { JobService } from '../../app/services/job.service';

@Component({
  selector: 'job-row',
  templateUrl: 'job-row.html'
})
export class JobRow {

  // open = false;
  machines: Machine[] = [];
  @Input() job:Job;
  @Input() customer:Customer;

  constructor(public navCtrl: NavController, public navParams: NavParams, public machineService: MachineService, public buildingService: BuildingService, public customerService: CustomerService) {
  }

  // isOpen(){
  //   return this.open;
  // }

  // openItem() {
  //   this.machines = [];
  //   this.getMachines();
  //   this.open = !this.open;
  // }
  // getMachineDetail(machine){
  //   this.navCtrl.parent.parent.push(MachineLanding, {job: this.job, machine: machine});
  // }

  getMachines() {
    this.machines = [];
    this.machines = this.machineService.getMachinesByJob(this.job.machineIdArray);
  }

  viewJob(job){
    console.log(job);
    this.getMachines();
    this.navCtrl.parent.parent.push(JobDetail, {job: job, machines: this.machines});
  }

}
