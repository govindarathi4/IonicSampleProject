import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MachineCard } from '../machine-card/machine-card.component';

@Component({
    selector: 'job-card',
    styles: [
        `ion-card { cursor: pointer }
        .tapped { background: #89C4F4 }
         .untapped { background: lightgray }`
    ],
    template: `<ion-card (tap)='cardTapped()' [ngClass]="showMachineCard == true ? 'tapped' : 'untapped'">
                    <ion-grid>
                        <ion-row>
                            <ion-col text-left>{{jobName}}</ion-col>
                            <ion-col text-right>{{operationDate | date: 'shortDate'}}</ion-col>
                        </ion-row>
                        <ion-row>
                            <ion-col text-left>{{branch}}</ion-col>
                            <ion-col text-right>{{numberOfMachines}} Machines</ion-col>
                        </ion-row>
                    </ion-grid>
                </ion-card>
                <div *ngIf='showMachineCard'>
                    <machine-card *ngFor='let card of machineCards'
                        [machineName]='card.MachineName'
                        [machineCode]='card.MachineCode'
                        [machineStatus]='card.MachineStatus'>
                    </machine-card>
                </div>`
})

export class JobCard{

    @Input() jobName: String;
    @Input() operationDate: String;
    @Input() branch: String;
    @Input() numberOfMachines: String;
    

    _showMachineCard: boolean;

    get showMachineCard(): boolean {
        return this._showMachineCard;
    }

    @Input('showMachineCard')
    set showMachineCard(value: boolean) {
        this._showMachineCard = value;
    }

    _machineCards: Array<MachineCard>;

    get machineCards(): Array<MachineCard> {
        return this._machineCards;
    }

    @Input('machineCards')
    set machineCards(value:Array<MachineCard>) {
        this._machineCards = value;
    }
   
    @Output() showOperationDetails = new EventEmitter();

    constructor(){
        
    }

    cardTapped(){
        this.showOperationDetails.emit(this);
    }
}