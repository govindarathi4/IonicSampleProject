import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'machine-card',
    styles: [
        `ion-card { background: #C5EFF7; } 
        .square { width: 1em; height: 1em; } 
        .close { background: #32db64; box-shadow: 1px 1px 1px 0px grey; } 
        .open { background: #FFFF33; box-shadow: 1px 1px 1px 0px grey; }`
    ],
    template: `<ion-card (tap)='cardTapped()'>
                    <ion-grid>
                        <ion-row>
                            <ion-col text-left>
                                <div class='square' [ngClass]="machineStatus == 'open' ? 'open' : 'close'"></div>
                            </ion-col>
                            <ion-col text-right>{{machineName}} ({{machineCode}})</ion-col>
                        </ion-row>
                    </ion-grid>
                </ion-card>`
})

export class MachineCard{

    @Input() machineName: String;
    @Input() machineCode: String;
    @Input() machineStatus: String;
   
    @Output() showMachineDetails = new EventEmitter();

    constructor(){
        
    }

    cardTapped(){
        this.showMachineDetails.emit(this);
    }
}