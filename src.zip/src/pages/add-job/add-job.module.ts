import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddJob } from './add-job';

@NgModule({
  declarations: [
    AddJob,
  ],
  imports: [
    IonicPageModule.forChild(AddJob),
  ],
  exports: [
    AddJob
  ]
})
export class AddJobModule {}
