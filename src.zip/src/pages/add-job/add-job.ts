import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { IonicPage, NavController, NavParams, LoadingController, Loading, AlertController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Branch } from '../../app/models/branch';
import { Building } from '../../app/models/building';
import { Customer } from '../../app/models/customer';
import { User } from '../../app/models/user';
import { Job } from '../../app/models/job';
import { BranchService } from '../../app/services/branch.service';
import { BuildingService } from '../../app/services/building.service';
import { JobService } from '../../app/services/job.service';
import { FindMachine } from '../find-machine/find-machine';
import geolibrary from 'geolib';

import { RequestMethodsService } from '../../commons/request-methods-service';
import { Constants } from '../../commons/constants';

import "rxjs/add/operator/map";
import "rxjs/add/operator/toPromise";
import { Observable } from "rxjs/Observable";

@IonicPage()
@Component({
  selector: 'page-add-job',
  templateUrl: 'add-job.html',
})
export class AddJob {

  branches: Branch[] = [];
  customers: Customer[] = [];
  buildings: Building[] = [];
  branchEmpty = true;
  nearestBuilding = {buildingId: "0", name:"default" };
  selectBranch = {BranchId: "0", BranchName: "Branch"};
  selectBuilding = {buildingId: "0", name:"default" };
  sentBuilding: Building;
  user: User;
  preferredBranch: string;
  selectedBranch: Branch;
  loading: Loading;
  haveClosest = false;
  selectTitle = "Building";
  testTitle = "TestText";
  protoJob: Job;
  branchArray: any[];
  customerArray: any[];
  buildingArray: any[];
  isCustomerDisabled: boolean = true;
  isBuildingDisabled: boolean = true;
  selectedBranchId: number;

  spinnerOptions = {
    content: 'Fetching data...',
    spinner: 'bubbles'
  }
  fetchDataSpinner: Loading;


  constructor(public navCtrl: NavController, 
    public navParams: NavParams, 
    public branchService: BranchService, 
    public buildingService: BuildingService, 
    public geolocation: Geolocation, 
    private loadingCtrl: LoadingController, 
    public alertCtrl: AlertController, 
    public jobService: JobService,
    private reqMethodsService: RequestMethodsService,
    private constants: Constants) {
      this.initialize();
  }

  initialize(){
    // this.showLoading()
    // this.getPreferredBranch();
    //this.branchService.initializeBranches();
    //this.buildingService.initializeBuildings();
    this.fetchDataSpinner = this.loadingCtrl.create(this.spinnerOptions);
    this.fetchDataSpinner.present();
    this.reqMethodsService.getData(this.constants.BASE_URL, this.constants.GET_BRANCHES)
    .subscribe((data) => {
        this.branchArray = data;
        this.fetchDataSpinner.dismiss();
    }, (error) => {
        console.log(JSON.stringify(error));
        this.fetchDataSpinner.dismiss();
    });

  }

  getCustomers(id){
    this.fetchDataSpinner = this.loadingCtrl.create(this.spinnerOptions);
    this.fetchDataSpinner.present();
    this.reqMethodsService.getData(this.constants.BASE_URL, this.constants.GET_CUSTOMERS, 'queryParam', id, 'branchId')
    .subscribe((data) => {
        this.customerArray = data;
        this.selectedBranchId = id;
        this.isCustomerDisabled = false;
        this.isBuildingDisabled = true;
        this.fetchDataSpinner.dismiss();      
    }, (error) => {
        console.log(JSON.stringify(error));
        this.fetchDataSpinner.dismiss();
    });
  }

  getBuildings(custId){
    this.fetchDataSpinner = this.loadingCtrl.create(this.spinnerOptions);
    this.fetchDataSpinner.present();
    this.reqMethodsService.getData(this.constants.BASE_URL, this.constants.GET_BUILDINGS, 'queryParam', this.selectedBranchId, 'branchId', custId, 'customerId')
    .subscribe((data) => {
        this.buildingArray = data;
        this.isBuildingDisabled = false;
        this.fetchDataSpinner.dismiss();        
    }, (error) => {
        console.log(JSON.stringify(error));
        this.fetchDataSpinner.dismiss();
    });
  }

  ionViewWillLoad() {
    //this.getBranches();
    //this.getPreferredBranch();
  }

  getBranches() {
    this.branches = this.branchService.getBranches();
  }

  getPreferredBranch() {
    this.preferredBranch = this.branchService.getPreferredBranch();
    if(this.preferredBranch){
      this.getBranchBuildings(this.preferredBranch);
    }
  }

  getBranchBuildings(branchId) {
    this.buildings = [];
    if(!branchId){
      branchId = this.preferredBranch;
    }
    let buildingIdArray = this.branchService.getBranchById(branchId).buildingIdArray;
    this.buildings = this.buildingService.getBranchBuildings(buildingIdArray);
    this.branchEmpty = false;
    this.findClosestBuilding();
  }

  activateSubmit(value){
    console.log(this.buildings);
    let tempBuilding = this.buildings.filter((building) => {
      return building.name === value;
    });
    this.selectBuilding = tempBuilding[0];
  }

  findClosestBuilding(){
    let nearestDistance = 0;
    this.nearestBuilding = {buildingId: "0", name:"default" };
      this.geolocation.getCurrentPosition().then((position) => {
        this.buildings.forEach((building) => {
          let distance = geolibrary.getDistance({"latitude": position.coords.latitude, "longitude": position.coords.longitude}, building.coordinates["coordinates"], 100, 1);
          if (distance < nearestDistance || nearestDistance == 0){
            nearestDistance = distance;
            this.nearestBuilding = building;
          }
        });
        if (this.selectBuilding.buildingId == "0"){
          this.selectBuilding = this.nearestBuilding;
        }
      }).catch((error: Response ) => {
        console.log("Error Message ", error)
      })
  }

  createJob(job){
    let jobId = this.jobService.createJobId();
    this.navCtrl.push(FindMachine, { buildingId: this.selectBuilding.buildingId , jobMachineIds: [], jobId: jobId});
  }

}
