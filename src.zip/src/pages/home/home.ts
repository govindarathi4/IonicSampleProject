import { Component, NgZone } from '@angular/core';
import { NavController, IonicPage, NavParams, LoadingController, Loading } from 'ionic-angular';

import { BLEable } from '../../app/models/bleable';
import { BleScanner } from '../../app/models/ble_scanner';
import { BleService } from '../../app/services/ble.service';
import { AthenaService } from '../../app/models/athena_service';
import { DevicePage } from '../device/device';

import { FindMachine } from '../find-machine/find-machine';
import { JobList } from '../job-list/job-list';
import { AddJob } from '../add-job/add-job';
import { LoginPage } from '../login/login';
import { Settings } from '../settings/settings';

import { AuthProvider } from '../../providers/authProvider';

import { JobService } from '../../app/services/job.service';
import { MachineService } from '../../app/services/machine.service';
import { BranchService } from '../../app/services/branch.service';
import { BuildingService } from '../../app/services/building.service';
import { TemplateService } from '../../app/services/template.service';
import { CustomerService } from '../../app/services/customer.service';

import {SearchListFilter} from '../../pipes/search-list-filter.pipe';

import { JobCard } from '../../components/cards/job-card/job-card.component';
import { MachineCard } from '../machine-card/machine-card.component';

import { RequestMethodsService } from '../../commons/request-methods-service';
import { Constants } from '../../commons/constants';

import "rxjs/add/operator/map";
import "rxjs/add/operator/toPromise";
import { Observable } from "rxjs/Observable";


@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
  str:String = "";
  ledIds = [0, 1, 2, 3, 4, 5, 6];
  availableDevices: Array<AthenaService> = [];
  username = '';
  email = '';
  bleable: BLEable;
  bleScanner: BleScanner;
  fakeNavPop: () => any;
  // pushNewMachinePage: any;
  //loading: Loading;

  jobCategories:string = 'open';

  jobsArrayOpen: any = [];
  jobsArrayClosed: any = [];

  startingPointOpen: number = 0;
  startingPointClosed: number = 0;

  queryString: String = '';

  opened = {status: "open"};
  closed = {status: "closed"};

  tab1root = JobList;
  tab2root = JobList;
  haveData= false;
  connected: Boolean = false;
  isCloseSegTappedFirstTime: Boolean = false;

  haveAllOpenJobsLoaded: boolean = false;
  haveAllClosedJobsLoaded: boolean = false;
  spinnerOptions = {
    content: 'Fetching data...',
    spinner: 'bubbles'
  }
  fetchDataSpinner: Loading;

  constructor(public navCtrl: NavController,
              private zone: NgZone,
              private bleService: BleService,
              private navParams: NavParams,
              private loadingCtrl: LoadingController,
              private authProvider : AuthProvider,
              private jobService: JobService,
              private machineService: MachineService,
              private branchService: BranchService,
              private buildingService: BuildingService,
              private templateService: TemplateService,
              private customerService: CustomerService,
              private reqMethodsService: RequestMethodsService,
              private constants: Constants
            ) {
    this.bleable = bleService.getBle();
    this.bleScanner = new BleScanner(this.bleable);
    this.fakeNavPop = navParams.get('fakeNavPop');
    this.initialize();
    this.connected = this.navParams.get('deviceConnected');
    
  }

  public logout() {
    this.authProvider.logout();
    this.navCtrl.setRoot(LoginPage);
  }

  public showSettings(){
    this.navCtrl.push(Settings);
  }

  initialize() {
    // this.machineService.initializeMachines();
    // this.templateService.initializeTemplates();
    // this.branchService.initializeBranches();
    // this.buildingService.initializeBuildings();
    // this.customerService.initializeCustomers();
    if (this.haveData == false){
      //this.showLoading();
      this.jobService.initializeJobs().then(() => {
          this.haveData = true;
          //this.loading.dismissAll(); // only when login page isn't set as root
          this.fetchDataSpinner = this.loadingCtrl.create(this.spinnerOptions);
          this.fetchDataSpinner.present();
          this.reqMethodsService.getJobs(this.constants.BASE_URL, this.constants.GET_JOBS, this.startingPointOpen, 'open')
          .subscribe((data) => {
              if(data.length == 0){
                  this.haveAllOpenJobsLoaded = true;
              }
              else if(this.startingPointClosed != data[data.length - 1].JobId){
                  this.jobsArrayOpen.push(...data);
                  this.startingPointOpen = data[data.length - 1].JobId;
              }
              
              let scrollEl: any = document.getElementsByClassName("scroll-content")[0];
              let that = this;
              scrollEl.addEventListener('scroll', function(ev) {
                    if ((scrollEl.scrollTop + scrollEl.clientHeight) > (scrollEl.scrollHeight-1)) {
                        if(that.jobCategories == 'open' && !that.haveAllOpenJobsLoaded){
                            scrollEl.style.overflowY = 'hidden';
                            that.fetchDataSpinner = that.loadingCtrl.create(that.spinnerOptions);
                            that.fetchDataSpinner.present();                         
                            that.getOpenJobs(that,scrollEl);
                        }
                        else if(that.jobCategories == 'closed' && !that.haveAllClosedJobsLoaded){
                            scrollEl.style.overflowY = 'hidden';
                            that.fetchDataSpinner = that.loadingCtrl.create(that.spinnerOptions);
                            that.fetchDataSpinner.present();                          
                            that.getClosedJobs(that,scrollEl);
                        }
                    } 
               });
               this.fetchDataSpinner.dismiss();
             },(error) => {
              this.fetchDataSpinner.dismiss();
          });
      });
    }
  }

  jobCategoryChanged(e){
      this.jobCategories == 'open' ? 'closed' : 'open';
      if(!this.isCloseSegTappedFirstTime){
          this.isCloseSegTappedFirstTime = true;
          let scrollEl: any = document.getElementsByClassName("scroll-content")[0];
          scrollEl.style.overflowY = 'hidden';
          this.fetchDataSpinner = this.loadingCtrl.create(this.spinnerOptions);
          this.fetchDataSpinner.present();
          this.getClosedJobs(this, scrollEl);
      }
  }

  searchDevices() {
    // this.showLoading();
    this.bleScanner.findAthenaService().subscribe(service => {
      if (this.deviceNotSavedYet(service)) {
        this.zone.run(() => {
          this.navCtrl.push(DevicePage, { item: service });
        });
      }
    });
    this.connected = true;
    // this.loading.dismiss();
  }

  disconnect() {
    // this.showLoading();
    location.reload();
    // this.loading.dismiss();
  }

  deviceNotSavedYet(device : AthenaService) : boolean {
    let uuid = device.uuid();
    return this.availableDevices.filter(d => d.uuid() === uuid).length == 0;
  }

//   showLoading() {
//     this.loading = this.loadingCtrl.create({
//       content: 'Updating data...',
//       dismissOnPageChange: true
//     });
//     this.loading.present();
//   }

  addNewJob() {
    this.navCtrl.push(AddJob);
  }

  itemTapped(event, item: AthenaService) {
    console.log("about to connect in home");
    this.navCtrl.push(DevicePage, { item: item });
      // actualService.connect().subscribe(foo => {
      //   // actualService.turnOnLed(1).then(this.handleLedPromiseSuccess).catch(this.handleLedPromiseError);
      // });
    // });
  }

  showMachineCard(e, jobId){
    if(!e.showMachineCard){
        this.reqMethodsService.getData(this.constants.BASE_URL, this.constants.GET_MACHINES, 'queryParam', jobId, 'jobId')
        .subscribe((data) => {
        if(data && data.length > 0){
            e.showMachineCard = true;
            e.machineCards = data;
        }
        }, (error) => {
            console.log(JSON.stringify(error));
        });
    }
    else{
        e.showMachineCard = false;
    }
  }

  getOpenJobs(obj,el){
      obj.reqMethodsService.getJobs(obj.constants.BASE_URL, obj.constants.GET_JOBS, obj.startingPointOpen, 'open')
      .subscribe((data) => {
          if(data.length == 0){
              obj.haveAllOpenJobsLoaded = true;
          }
          else if(obj.startingPointClosed != data[data.length - 1].JobId){
              obj.jobsArrayOpen.push(...data);
              obj.startingPointOpen = data[data.length - 1].JobId;
          }
          obj.fetchDataSpinner.dismiss();  
          el.style.overflowY = 'scroll';
      },(error) => {
          obj.fetchDataSpinner.dismiss(); 
          el.style.overflowY = 'scroll';
      });
  }

  getClosedJobs(obj,el){
      obj.reqMethodsService.getJobs(obj.constants.BASE_URL, obj.constants.GET_JOBS, obj.startingPointClosed, 'closed')
      .subscribe((data) => {
          if(data.length == 0){
              obj.haveAllClosedJobsLoaded = true;
          }
          else if(obj.startingPointClosed != data[data.length - 1].JobId){
              obj.jobsArrayClosed.push(...data);
              obj.startingPointClosed = data[data.length - 1].JobId;
          }
          obj.fetchDataSpinner.dismiss(); 
          el.style.overflowY = 'scroll';
      },(error) => {
          obj.fetchDataSpinner.dismiss(); 
          el.style.overflowY = 'scroll';
      });
  }

}
