import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Camera } from 'ionic-native';
import { UserService } from '../../app/services/user.service';
import { MachineService } from '../../app/services/machine.service';
import { RecordingService } from '../../app/services/recording.service';
import { Note } from '../../app/models/note';
import { User } from '../../app/models/user';


@IonicPage()
@Component({
  selector: 'page-create-note',
  templateUrl: 'create-note.html',
})
export class CreateNotePage {

  public base64Image: string = "assets/img/empty-image.png";
  machine;
  currentUser: User;
  readyToAdd = false;
  noteText: string = "";
  recordingId: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public userService: UserService, public recordingService: RecordingService, public machineService: MachineService) {
    this.machine = navParams.get('machine');
    this.recordingId = navParams.get('recordingId');
    this.currentUser = this.userService.getUser();
  }

  ionViewDidLoad() {
  }

  takePicture(){
    Camera.getPicture({
      destinationType: Camera.DestinationType.DATA_URL,
      targetWidth: 1000,
      targetHeight: 1000
    }).then((imageData) => {
      this.base64Image = "data:image/jpeg;base64," + imageData;
      this.readyToAdd = true;
    }, (err) => {
      console.log(err);
    });
  }


  addText(text){
    if(text.length > 0){
      this.readyToAdd = true;
    } else {
      this.readyToAdd = false;
    }
  }

//STILL A WORK IN PROGESS - THIS IS THE NEXT STEP!
  submitNote(){
    if(this.readyToAdd){
      let tempNote = new Note(this.machine.machineSerial, this.currentUser.userName, this.currentUser.userId);
      if (this.base64Image != "assets/img/empty-image.png" ){
        tempNote.addNotePic(this.base64Image);
      }
      if (this.noteText != ""){
        tempNote.addNoteText(this.noteText);
      }
      this.machineService.addNote(this.machine.machineSerial, tempNote);
    }
    this.navCtrl.pop();
  }
}
