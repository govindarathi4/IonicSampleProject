import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewMachineTemplate } from './new-machine-template';

@NgModule({
  declarations: [
    NewMachineTemplate,
  ],
  imports: [
    IonicPageModule.forChild(NewMachineTemplate),
  ],
  exports: [
    NewMachineTemplate
  ]
})
export class NewMachineTemplateModule {}
