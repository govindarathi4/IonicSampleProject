import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Camera } from 'ionic-native';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NumberValidator } from '../../validators/number';
import { Template } from '../../app/models/template';
import { DataStore } from '../../providers/data-store';
import { MachineLanding } from '../machineLanding/machineLanding';
import { MachineService } from '../../app/services/machine.service';

@IonicPage()
@Component({
  selector: 'page-new-machine-template',
  templateUrl: 'new-machine-template.html',
})
export class NewMachineTemplate {

  @ViewChild('newMachineSlider') newMachineSlider: any;

  template: any;
  slideOneForm: FormGroup;
  slideTwoForm: FormGroup;
  slideThreeForm: FormGroup;
  slideFourForm: FormGroup;
  pictureSlideForm: FormGroup;
  base64Image: string;
  buildingId: string;

  submitAttempt: boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public machineService: MachineService) {
    this.template = navParams.get('template');
    this.buildingId = navParams.get('buildingId');

    this.slideOneForm = formBuilder.group({
      jciAssetId: ['', Validators.required],
      modelNumber: ['', Validators.required],
      sN: ['', Validators.required],
      criticality: ['', Validators.required],
      machineDutyType: ['', Validators.required]
    });

    this.slideTwoForm = formBuilder.group({
      starterType: ['', Validators.required],
      starterIncomingLineFrequency: ['', Validators.required],
      electricMotorMake: [''],
      electricMotorModel: [''],
      electricMotorVolts: [''],
      electricMotorHp: [''],
      electricMotorFrame: ['']
    });

    this.slideThreeForm = formBuilder.group({
      nonDriveEndBallBearingOem: [''],
      nonDriveEndBallBearingBearingNumber: [''],
      driveEndBallBearingOem: [''],
      driveEndBallBearingBearingNumber: ['']
    });

    this.slideFourForm = formBuilder.group({
      refrigerantModel: ['', Validators.required],
      refrigerantSn: ['', Validators.required],
      refrigerantHotGasBypass: [''],
      gearSetSpeedCode: ['', Validators.required]
    });

    this.pictureSlideForm = formBuilder.group({
      base64Image: [this.base64Image]
    })

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewMachineTemplate');
    console.log(this.navParams.get('template'));
  }


  takePicture(){
    Camera.getPicture({
      destinationType: Camera.DestinationType.DATA_URL,
      targetWidth: 1000,
      targetHeight: 1000
    }).then((imageData) => {
      this.base64Image = "data:image/jpeg;base64," + imageData;
    }, (err) => {
      console.log(err);
    });
  }


    next(){
      this.newMachineSlider.slideNext();
    }

    prev(){
      this.newMachineSlider.slidePrev();
    }

    save(){
      this.submitAttempt = true;

      if (!this.slideOneForm.valid){
        this.newMachineSlider.slideTo(0);
      } else if (!this.slideTwoForm.valid){
        this.newMachineSlider.slideTo(1);
      } else if (!this.slideThreeForm.valid){
        this.newMachineSlider.slideTo(2);
      } else if (!this.slideFourForm.valid){
        this.newMachineSlider.slideTo(4);
      } else if (!this.pictureSlideForm.valid){
        this.newMachineSlider.slideTo(3);
      } else {
        console.log("success!")
        console.log(this.slideOneForm.value);
        console.log(this.slideTwoForm.value);
        console.log(this.slideThreeForm.value);
        console.log(this.slideFourForm.value);
        console.log(this.pictureSlideForm.value);

        let machine = {
          buildingId: this.buildingId,
          machineName: "Machine" + this.buildingId,
          templateId: this.template.id,
          jciAssetId: this.slideOneForm.value['jciAssetId'],
          modelNumber: this.slideOneForm.value['modelNumber'],
          sN: this.slideOneForm.value['sN'],
          criticality: this.slideOneForm.value['criticality'],
          machineDutyType: this.slideOneForm.value['machineDutyType'],
          starterType: this.slideTwoForm.value['starterType'],
          starterIncomingLineFrequency: this.slideTwoForm.value['starterIncomingLineFrequency'],
          electricMotorMake: this.slideTwoForm.value['electricMotorMake'],
          electricMotorModel: this.slideTwoForm.value['electricMotorModel'],
          electricMotorVolts: this.slideTwoForm.value['electricMotorVolts'],
          electricMotorHp: this.slideTwoForm.value['electricMotorHp'],
          electricMotorFrame: this.slideTwoForm.value['electricMotorFrame'],
          nonDriveEndBallBearingOem: this.slideThreeForm.value['nonDriveEndBallBearingOem'],
          nonDriveEndBallBearingBearingNumber: this.slideThreeForm.value['nonDriveEndBallBearingBearingNumber'],
          driveEndBallBearingOem: this.slideThreeForm.value['driveEndBallBearingOem'],
          driveEndBallBearingBearingNumber: this.slideThreeForm.value['driveEndBallBearingBearingNumber'],
          base64Image: this.pictureSlideForm.value['base64Image'],
          refrigerantModel: this.slideFourForm.value['refrigerantModel'],
          refrigerantSn: this.slideFourForm.value['refrigerantSn'],
          refrigerantHotGasBypass: this.slideFourForm.value['refrigerantHotGasBypass'],
          gearSetSpeedCode: this.slideFourForm.value['gearSetSpeedCode'],
        }

        this.machineService.addMachine(machine);

        this.navCtrl.remove(2,2);
        this.navCtrl.pop();
      }
    }

}
