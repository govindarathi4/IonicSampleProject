import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { BranchService } from '../../app/services/branch.service';
import { Branch } from '../../app/models/branch';


@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class Settings {

  branches: Branch[] = [];
  preferredBranch: String;

  constructor(public navCtrl: NavController, public navParams: NavParams, public branchService: BranchService) {
    this.branches = this.branchService.getBranches();
    this.getPreferredBranch();
  }

  ionViewDidLoad() {

  }

  setPreferredBranch(branchName){
    console.log(branchName);
    this.branchService.setPreferredBranch(branchName);
  }

  getPreferredBranch(){
      this.preferredBranch = this.branchService.getPreferredBranch();
  }
}
