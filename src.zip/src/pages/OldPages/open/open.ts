// import { Component } from '@angular/core';
// import { IonicPage, NavController, NavParams } from 'ionic-angular';
// import { Job } from  '../../app/models/job';
// import { DataStore } from '../../providers/data-store';
// // import { JobRow } from '../../components/job-row/job-row';
//
// @IonicPage()
// @Component({
//   selector: 'page-open',
//   templateUrl: 'open.html',
// })
// export class Open {
//
//   openItems: Array<any> = [];
//   jobs: Job[] = [];
//
//   constructor(public navCtrl: NavController, public navParams: NavParams, public dataStore: DataStore) {
//
//     // let jobData = dataStore.getJobs().then((array) => {
//     //   if (array) {
//     //     let jobData = JSON.parse(array);
//     //
//     //     jobData.map((job) => {
//     //       let instance = new Job(job.id, job.jobName, job.buildingId, job.machineIdArray, job.jobStatus);
//     //       // console.log('Instance: ', instance);
//     //       this.jobs.push(instance);
//     //     });
//     //   }
//     // });
//   }
//
//   ionViewDidLoad() {
//   }
//
//   viewJob(event, job){
//     event.stopPropagation();
//     this.navCtrl.parent.parent.push(Job, {job: job});
//   }
// }
