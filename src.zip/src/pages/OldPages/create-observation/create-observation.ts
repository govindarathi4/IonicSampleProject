import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Camera } from 'ionic-native';
// import { RecordingService } from '../../app/services/recording.service';


@Component({
  selector: 'page-create-observation',
  templateUrl: 'create-observation.html',
})
export class CreateObservationPage {

  public base64Image: string;
  machine;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.machine = navParams.get('machine');
  }

  ionViewDidLoad() {

  }

  takePicture(){
    Camera.getPicture({
      destinationType: Camera.DestinationType.DATA_URL,
      targetWidth: 1000,
      targetHeight: 1000
    }).then((imageData) => {
      this.base64Image = "data:image/jpeg;base64," + imageData;
    }, (err) => {
      console.log(err);
    });
  }

  addObservation(){

  }


}
