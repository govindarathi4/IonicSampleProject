// import { Component } from '@angular/core';
// import { IonicPage, NavController, NavParams } from 'ionic-angular';
// import { MockJobs } from '../../providers/mockjobs';
// import { ClosedJob } from '../closed-job/closed-job';

//
// @IonicPage()
// @Component({
//   selector: 'page-closed',
//   templateUrl: 'closed.html',
// })
// export class Closed {
//
//   openItems: Array<any> = [];
//   jobs: Array<any> = [];
//
//
//   constructor(public navCtrl: NavController, public navParams: NavParams) {
//     // this.jobs = mockJobs.getClosed();
//   }
//
//   ionViewDidLoad() {
//   }
//
//   viewJob(event, job){
//     event.stopPropagation();
//     this.navCtrl.parent.parent.push(ClosedJob, {job: job});
//   }
//
// }
