import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
// import { ProgressBar } from '../../components/progress-bar/progress-bar';

@Component({
  selector: 'page-closed-job',
  templateUrl: 'closed-job.html',
})
export class ClosedJob {

  job;
  loadProgress = 50;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.job = navParams.get('job');
  }

  ionViewDidLoad() {

  }

}
