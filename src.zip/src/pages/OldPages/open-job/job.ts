// import { Component } from '@angular/core';
// import { IonicPage, NavController, NavParams } from 'ionic-angular';
// import { NewMachinePage } from '../new-machine/new-machine';
//
//
// @IonicPage()
// @Component({
//   selector: 'page-job',
//   templateUrl: 'job.html',
// })
// export class Job {
//
//   // job;
//
//   constructor(public navCtrl: NavController, public navParams: NavParams) {
//     // this.job = navParams.get('job');
//   }
//
//   ionViewDidLoad() {
//
//   }
//
//   addNewMachine(){
//     this.navCtrl.push(NewMachinePage);
//   }
//
// }
