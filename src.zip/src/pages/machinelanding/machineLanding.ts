import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { BuildingService } from '../../app/services/building.service';
import { CustomerService } from '../../app/services/customer.service';
import { RecordingService } from '../../app/services/recording.service';
import { PreRecordingPage } from '../pre-recording/pre-recording';
import { Recording } from '../../app/models/recording';


// @IonicPage()
@Component({
  selector: 'page-machineLanding',
  templateUrl: 'machineLanding.html',
})
export class MachineLanding {

  operatingConditions: FormGroup;
  mechanicsObservations: FormGroup;
  recentRepairs: FormGroup;
  submitAttempt: boolean = false;
  machine;
  building;
  customer;

  constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public buildingService: BuildingService, public customerService: CustomerService, public storage: Storage, public recordingService: RecordingService) {
    this.machine = navParams.get('machine');
    console.log("In landing page constructor", this.machine);
    this.building = this.buildingService.getBuildingByID(this.machine.buildingId);
    this.customer = this.customerService.getCustomerById(this.building.customerId);


    this.operatingConditions = formBuilder.group({
      vfdFrequency: ['', Validators.required],
      fanSpeed: ['', Validators.required],
      operatingLoad: ['', Validators.required],
      operatingHours: ['', Validators.required]
    });

    this.mechanicsObservations = formBuilder.group({
      sights: ['', Validators.required],
      sounds: ['', Validators.required],
      feel: ['', Validators.required],
      smell: ['', Validators.required]
    });

    this.recentRepairs = formBuilder.group({
      bearings: ['', Validators.required],
      bolts: ['', Validators.required],
      brackets: ['', Validators.required],
      knownIssues: ['', Validators.required]
    });

  }
  ionViewDidLoad() {

  }

  save(){
    this.submitAttempt = true;
    console.log("success!")
    console.log(this.operatingConditions.value);
    console.log(this.mechanicsObservations.value);
    console.log(this.recentRepairs.value);
      // this.navCtrl.push(FindMachine);
  }

  start(){
    console.log(this.machine);
    let recording = new Recording(this.recordingService.createRecordingId(),new Date(), this.machine.machineName, this.machine.machineSerial, "open");
    this.recordingService.addRecording(recording);
    this.navCtrl.push(PreRecordingPage,{machine: this.machine, recording: recording});
  }



}
