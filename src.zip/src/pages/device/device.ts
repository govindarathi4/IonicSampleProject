import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../../pages/home/home';
import { AthenaService } from '../../app/models/athena_service';

@IonicPage()
@Component({
  selector: 'page-device',
  templateUrl: 'device.html',
})
export class DevicePage {
  selectedDevice: AthenaService;
  nextCollectionAction: string = "Start";
  availableLedIds = [0, 1, 2, 3];
  isUploading = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, private zone: NgZone) {
    this.selectedDevice = navParams.get('item');

    this.selectedDevice.connect(service => {
      this.zone.run(() => {})
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Device');
  }

  toggleCollecting() {
    if (this.nextCollectionAction === "Start") {
      this.selectedDevice.startCollecting();
      this.nextCollectionAction = "Stop";
    } else {
      this.selectedDevice.stopCollecting();
      this.nextCollectionAction = "Start";
    }
  }

  // toggleLed(id) {
  //   this.selectedDevice.toggleLed(id);
  // }

  upload() {
    this.isUploading = true;
    setTimeout(this.showUploadButton, 5000);
  }

  showUploadButton() {
    console.log('upload shown');
    this.zone.run(() => {
      this.isUploading = false;
    });
  }

  goHome(){
    this.navCtrl.pop();
    // this.navCtrl.push(HomePage, {
    //   deviceConnected: true
    // });
  }
}
