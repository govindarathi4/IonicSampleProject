import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobDetail } from './job-detail';

@NgModule({
  declarations: [
    JobDetail,
  ],
  imports: [
    IonicPageModule.forChild(JobDetail),
  ],
  exports: [
    JobDetail
  ]
})
export class JobDetailModule {}
