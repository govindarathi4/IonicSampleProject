import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';
import { ProgressBar } from '../../components/progress-bar/progress-bar';
import { FindMachine } from '../find-machine/find-machine';
import { MachineLanding } from '../machineLanding/machineLanding';
import { MachineService } from '../../app/services/machine.service';
import { JobService } from '../../app/services/job.service';
// import { JobDetail } from '../../pages/job-detail/job-detail';


@IonicPage()
@Component({
  selector: 'page-job-detail',
  templateUrl: 'job-detail.html',
})
export class JobDetail {

  job;
  jobStatus;
  machines;
  tempProgress = 50;

  constructor(public navCtrl: NavController, public navParams: NavParams, public machineService: MachineService, public events: Events, public jobService: JobService) {
    this.job = navParams.get('job');
    console.log(this.job);
    this.jobStatus = this.job.jobStatus;
    this.machines = machineService.getMachinesByJob(this.job.machineIdArray);
    // this.recordings =
  }

  ionViewWillLoad() {
  }

  findMachine(){
    this.navCtrl.push(FindMachine, { buildingId: this.job.buildingId, jobMachineIds: this.job.machineIdArray, jobId: this.job.jobId});
  }

  getMachineDetail(machine){
    this.navCtrl.push(MachineLanding, {job: this.job, machine: machine});
  }
}
