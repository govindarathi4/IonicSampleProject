import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreateObservationPage } from './create-observation';

@NgModule({
  declarations: [
    CreateObservationPage,
  ],
  imports: [
    IonicPageModule.forChild(CreateObservationPage),
  ],
  exports: [
    CreateObservationPage
  ]
})
export class CreateObservationPageModule {}
