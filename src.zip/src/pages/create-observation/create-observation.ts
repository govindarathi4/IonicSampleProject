import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Camera } from 'ionic-native';
import { RecordingService } from '../../app/services/recording.service';
import { UserService } from '../../app/services/user.service';
import { Observation } from '../../app/models/observation';
import { User } from '../../app/models/user';
import { Machine } from '../../app/models/machine';



@IonicPage()
@Component({
  selector: 'page-create-observation',
  templateUrl: 'create-observation.html',
})
export class CreateObservationPage {

  public base64Image: string = "assets/img/empty-image.png";
  machine;
  currentUser: User;
  readyToAdd = false;
  noteText: string = "";
  recordingId: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public userService: UserService, public recordingService: RecordingService) {
    this.machine = navParams.get('machine');
    this.recordingId = navParams.get('recordingId');
    this.currentUser = this.userService.getUser();
  }

  ionViewDidLoad() {

  }

  takePicture(){
    Camera.getPicture({
      destinationType: Camera.DestinationType.DATA_URL,
      targetWidth: 1000,
      targetHeight: 1000
    }).then((imageData) => {
      this.base64Image = "data:image/jpeg;base64," + imageData;
      this.readyToAdd = true;
    }, (err) => {
      console.log(err);
    });
  }

  addText(text){
    if(text.length > 0){
      this.readyToAdd = true;
    } else {
      this.readyToAdd = false;
    }
  }

  submitObservation(){
    console.log("The Current User", this.currentUser);
    if(this.readyToAdd){
      let tempObservation = new Observation(this.machine.machineSerial, this.currentUser.userName, this.currentUser.userId);
      console.log("In Submit Observation", tempObservation);
      if (this.base64Image != "assets/img/empty-image.png" ){
        tempObservation.addPicture(this.base64Image);
      }
      if (this.noteText != ""){
        tempObservation.addText(this.noteText);
      }
      this.recordingService.addObservation(this.recordingId, tempObservation);
    }
    this.navCtrl.pop();
  }


}
