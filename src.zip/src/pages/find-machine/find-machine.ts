import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events, ViewController, AlertController } from 'ionic-angular';
import { NewMachinePage } from '../new-machine/new-machine';
import { Machine } from '../../app/models/machine';
import { MachineService } from '../../app/services/machine.service';
import { JobService } from '../../app/services/job.service';
import { DataStore } from '../../providers/data-store';
import { JobDetail } from '../../pages/job-detail/job-detail';
import { HomePage } from '../../pages/home/home';
import { Job } from '../../app/models/job';

@IonicPage()
@Component({
  selector: 'page-find-machine',
  templateUrl: 'find-machine.html',
})
export class FindMachine {

  searchString: string = '';
  searchResults: Machine[] = [];
  filteredResults: Machine[] = [];
  jobMachineIdArray: String[] = [];  // array of serial numbers of machines in job
  machinesToAdd: Machine[] = [];
  buildingId: string;
  machineFilter: string = "";
  readyToAdd = false;
  jobId: string;
  selectBuilding = {buildingId: "0", name:"default" };


  constructor(public navCtrl: NavController, public navParams: NavParams, public machineService: MachineService, public jobService: JobService, public events: Events, public viewCtrl: ViewController, public alertCtrl: AlertController ) {
    this.jobId = navParams.get('jobId');
    this.buildingId = navParams.get('buildingId');
    this.jobMachineIdArray = navParams.get('jobMachineIds');
    this.getSearchResults();
  }

  ionViewDidLoad() {
  }

  addNewMachine(){
    this.navCtrl.push(NewMachinePage, { buildingId: this.selectBuilding.buildingId });
  }

  getSearchResults(){
    let buildingMachines = this.machineService.getMachinesByBuilding(this.buildingId.toString());
    console.log(buildingMachines);
    buildingMachines.forEach((machine) => {
      if(this.jobMachineIdArray.indexOf(String(machine.machineSerial)) < 0) {
        this.searchResults.push(machine);
      }
      this.filteredResults = this.searchResults;
    });
  }

  filterByMachineType(){
    this.filteredResults = [];
    this.searchResults.map((machine) => {
      if(machine.machineType === this.machineFilter){
        this.filteredResults.push(machine);
      }
    });
  }

  searchMachines(){
    if (this.machineFilter == ""){
      this.filteredResults = this.searchResults;
    } else {
      this.filterByMachineType()
    }
    let results = [];
    this.filteredResults.map((machine) => {
      if(machine.machineName.includes(this.searchString)){
        results.push(machine);
      }
    });
    this.filteredResults = results;
  }

  resetSearch(event){
    this.filteredResults = this.searchResults;
  }

  updateAddList(machine){
    let found = false;

    if (this.machinesToAdd.length > 0){
      for(var i = 0; i < this.machinesToAdd.length; i++){
        if (this.machinesToAdd[i] == machine.machineSerial){
          this.machinesToAdd.splice(i, 1);
          found = true;
        }
      }
    } else {
      this.machinesToAdd.push(machine.machineSerial);
      found = true;
    }

    if (!found){
      this.machinesToAdd.push(machine.machineSerial);
    }

    if (this.machinesToAdd.length < 1){
      this.readyToAdd = false;
    } else {
      this.readyToAdd = true;
    }
  }

  addMachinesToJob(){
    if (this.jobService.checkIfJob(this.jobId)){
      console.log(this.jobId);
      this.jobService.addMachinesToJob(this.machinesToAdd, this.jobId);
      let job = this.jobService.getJobById(this.jobId);
      this.jobService.saveJobs();
      this.navCtrl.push(JobDetail, {job: job}).then(() => {
        const index = this.viewCtrl.index;
        this.navCtrl.remove(index-1, 2);
      });
    } else {
      let jobName = "";
      let alert = this.alertCtrl.create({
        title: 'Name Your Job',
        inputs: [
          {
            name: 'jobName',
            placeholder: 'Job Name'
          }
        ],
        buttons: [
          {
            text: 'Submit',
            handler: data => {
              let jobName = data.jobName;
              let job = new Job(this.jobId.toString(), jobName, this.buildingId, [], "open", []);
              this.jobService.addJob(job);
              this.jobService.addMachinesToJob(this.machinesToAdd, this.jobId);
              this.jobService.saveJobs();
              this.navCtrl.setRoot(HomePage);
            }
          }
        ]
      });
      alert.present();
    }
  }

}
