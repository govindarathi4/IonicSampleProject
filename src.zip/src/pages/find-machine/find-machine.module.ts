import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FindMachine } from './find-machine';

@NgModule({
  declarations: [
    FindMachine,
  ],
  imports: [
    IonicPageModule.forChild(FindMachine),
  ],
  exports: [
    FindMachine
  ]
})
export class FindMachineModule {}
