import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FindMachine } from '../find-machine/find-machine';
import { Template } from '../../app/models/template';
import { NewMachineTemplate } from '../new-machine-template/new-machine-template';
import { TemplateService } from '../../app/services/template.service';
import { DataStore } from '../../providers/data-store';

@IonicPage()
@Component({
  selector: 'page-new-machine',
  templateUrl: 'new-machine.html',
})
export class NewMachinePage {

  chillerForm: FormGroup;
  fanForm: FormGroup;
  pumpForm: FormGroup;
  otherForm: FormGroup;

  templates: Template[] = this.templateService.templates;
  templateList: Template[] = [];
  buildingId: string;

  make: string;
  model: string;
  drivenType: string;
  motorOrientation: string;
  intermediary: string;
  bearings: number;
  supportStyle: string;
  otherMachineType: string;
  driveType: string;
  hasMotor: string;
  chiller: boolean = false;
  fan: boolean = false;
  pump: boolean = false;
  otherMachine: boolean = false;
  selectBuilding = {buildingId: "0", name:"default" };


  constructor(public navCtrl: NavController, public formBuilder: FormBuilder, public templateService: TemplateService, public navParams: NavParams) {

    this.chillerForm = formBuilder.group({
      chillerMake: [''],
      chillerCooled: [''],
      chillerModel: ['']
    });

    this.fanForm = formBuilder.group({
      fanDrivenType: [''],
      fanMotorOrientation: [''],
      fanIntermediary: [''],
      fanBearings: ['']
    });

    this.pumpForm = formBuilder.group({
      pumpMotorOrientation: [''],
      pumpIntermediary: [''],
      pumpBearings: [''],
      pumpSupportStyle: ['']
    });

    this.otherForm = formBuilder.group({
      otherEquipmentType: [''],
      otherHasMotor: [''],
      otherDriveType: [''],
      otherBearings: ['']
    });

    this.buildingId = navParams.get('buildingId');

  }

  showChillerForm() {
    this.chiller = !this.chiller;
    this.fan = false;
    this.pump = false;
    this.otherMachine = false;
    this.templateList = [];
  }

  showFanForm() {
    this.chiller = false;
    this.fan = !this.fan;
    this.pump = false;
    this.otherMachine = false;
    this.templateList = [];
  }

  showPumpForm() {
    this.chiller = false;
    this.fan = false;
    this.pump = !this.pump;
    this.otherMachine = false;
    this.templateList = [];
  }

  showOtherForm() {
    this.chiller = false;
    this.fan = false;
    this.pump = false;
    this.otherMachine = !this.otherMachine;
    this.templateList = [];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewMachinePage');
  }

  getChillerMake(make){
    this.make = make;
    this.chillerModelOptions();
    this.templateList = [];
    let templateList = this.templateList;
    this.templates.forEach(function(template){
      if (template.make == make) {
        console.log(template);
        templateList.push(template);
      }
    });
  }

  getChillerModel(model){
    this.model = model;
    this.templateList = [];
    let templateList = this.templateList;
    this.templates.forEach(function(template){
      if (template.model == model) {
        console.log(template);
        templateList.push(template);
      }
    });
  }

  getFanFilters(field, item){
    this[field] = item;
    let drivenType = this.drivenType;
    let motorOrientation = this.motorOrientation;
    let intermediary = this.intermediary;
    let bearings = this.bearings;
    this.templateList = [];
    let templateList = this.templateList;
    this.templates.forEach(function(template){
      if (template.machineType == 'Fan'){
        if (!drivenType || template.drivenType == drivenType){
          if (!motorOrientation || template.motorOrientation == motorOrientation){
            if (!intermediary || template.intermediaryType == intermediary){
              if (!bearings || template.drivenBearings == bearings){
                templateList.push(template);
              }
            }
          }
        }
      }
    });
  }

  getPumpFilters(field, item){
    this[field] = item;
    let supportStyle = this.supportStyle;
    let motorOrientation = this.motorOrientation;
    let intermediary = this.intermediary;
    let bearings = this.bearings;
    this.templateList = [];
    let templateList = this.templateList;
    this.templates.forEach(function(template){
      if (template.machineType == 'Pump'){
        if (!supportStyle || template.drivenSupportStyle == supportStyle){
          if (!motorOrientation || template.motorOrientation == motorOrientation){
            if (!intermediary || template.intermediaryType == intermediary){
              if (!bearings || template.drivenBearings == bearings){
                templateList.push(template);
              }
            }
          }
        }
      }
    });
  }

  getOtherMachineFilters(field, item){
    this[field] = item;
    let machineType = this.otherMachineType;
    let bearings = this.bearings;
    let driveType = this.driveType;
    let hasMotor = this.hasMotor;
    this.templateList = [];
    let templateList = this.templateList;
    this.templates.forEach(function(template){
      if (template.machineType == machineType){
        if (!driveType || template.driveType == driveType) {
          if (!hasMotor || template.hasMotor == hasMotor){
            if (!bearings || template.drivenBearings == bearings){
              templateList.push(template);
            }
          }
        }
      }
    });
  }

  otherDriveOptions(){
    let otherDriveList = [];

    this.templates.forEach(function(template){
      if (template.machineType != 'Chiller' && template.machineType != 'Pump' && template.machineType != 'Fan' && otherDriveList.indexOf(template.driveType) < 0){
        otherDriveList.push(template.driveType);
      }
    });
    return otherDriveList;

  }

  otherMachineOptions(){
    let otherMachineList = [];

    this.templates.forEach(function(template){
      if (template.machineType != 'Chiller' && template.machineType != 'Pump' && template.machineType != 'Fan' && otherMachineList.indexOf(template.machineType) < 0){
        otherMachineList.push(template.machineType);
      }
    });
    return otherMachineList;
  }

  drivenBearingsOptions(){
    let drivenBearingsList = [0];

    this.templates.forEach(function(template){
      if (template.drivenBearings && drivenBearingsList.indexOf(template.drivenBearings) < 0){
        drivenBearingsList.push(template.drivenBearings);
      }
    });
    drivenBearingsList = drivenBearingsList.sort(function(a,b){ return a - b; });
    return drivenBearingsList;
  }

  changeValue(form, value, field) {
    this[form][field] = value;
    console.log(this[form][field] = value)
  }

  chillerMakeOptions(){
    let chillerMakes = [];

    this.templates.forEach(function(template){
      if (template.machineType == 'Chiller' && template.make && chillerMakes.indexOf(template.make) < 0){
        chillerMakes.push(template.make);
      }
    });
    return chillerMakes;
  }

  chillerModelOptions(){
    let chillerModels = [];
    let make = this.make
    if (this.make != null || this.make != undefined){
      this.templates.forEach(function(template){
        if (template.machineType == 'Chiller' && template.make == make && template.model && chillerModels.indexOf(template.model) < 0){
          chillerModels.push(template.model);
        }
      });
      return chillerModels;
    }
  }

  goToTemplate(template) {
    console.log(template);
    this.navCtrl.push(NewMachineTemplate, {
      template: template,
      buildingId: this.selectBuilding.buildingId
    });
  }
}
