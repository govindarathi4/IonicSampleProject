import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewMachinePage } from './new-machine';

@NgModule({
  declarations: [
    NewMachinePage,
  ],
  imports: [
    IonicPageModule.forChild(NewMachinePage),
  ],
  exports: [
    NewMachinePage
  ]
})
export class NewMachineModule {}
