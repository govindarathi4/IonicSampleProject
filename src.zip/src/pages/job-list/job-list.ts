import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { Job } from  '../../app/models/job';
import { JobService } from '../../app/services/job.service';
import { BuildingService } from '../../app/services/building.service';
import { CustomerService } from '../../app/services/customer.service';
// import { DataStore } from '../../providers/data-store';

@IonicPage()
@Component({
  selector: 'page-job-list',
  templateUrl: 'job-list.html',
})

export class JobList {

  jobs: Job[] = [];
  loading: Loading;
  status;

  constructor(public navCtrl: NavController, public navParams: NavParams, private loadingCtrl: LoadingController, public jobService: JobService, public buildingService: BuildingService, public customerService: CustomerService ) {
    this.status = this.navParams.get('status') || 'open';
    this.jobs = [];
    this.loadJobs();
  }

  ionViewWillEnter(){
    this.jobs = [];
    this.loadJobs();
    console.log("In Job List View Will Enter", this.jobs);
  }

  loadJobs() {
    this.jobs = this.status === "open" ? this.jobService.getOpenJobs() : this.jobService.getClosedJobs();
  }

  viewJob(job){
    this.navCtrl.parent.parent.push(Job, {job: job});
  }

  getCustomerName(job){
    let customerId = this.buildingService.getCustomerByBuildingID(job.buildingId);
    let customer = this.customerService.getCustomerById(customerId);
    return customer;
  }
}
