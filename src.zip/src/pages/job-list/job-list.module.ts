import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobList } from './job-list';

@NgModule({
  declarations: [
    JobList,
  ],
  imports: [
    IonicPageModule.forChild(JobList),
  ],
  exports: [
    JobList
  ]
})
export class JobListModule {}
