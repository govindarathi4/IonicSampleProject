import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { RecordingService } from '../../app/services/recording.service';
import { BleService } from '../../app/services/ble.service';


@IonicPage()
@Component({
  selector: 'page-recording',
  templateUrl: 'recording.html',
})
export class RecordingPage {

  machine;
  recording;
  ble;

  constructor(public navCtrl: NavController, public navParams: NavParams, public bleService: BleService, public alertCtrl: AlertController) {
    this.machine = navParams.get('machine');
    this.recording = navParams.get('recording');
    this.ble = this.bleService.getBle();
  }

  ionViewDidLoad() {

  }

  startRecording(){
    let result = this.bleService.writeChar("72B40B43-7B8C-41A8-AF31-B547AD292B97")
    console.log(result);

    let alert = this.alertCtrl.create({
    title: 'Start Recording Sent',
    message: 'The message to record has been sent.  Soon you will receive this information from the device.',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      },
      {
        text: 'Ok',
        handler: () => {
          console.log('Ok clicked');
        }
      }
    ]
  });
  alert.present();
  }

}
