import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecordingPage } from './recording';

@NgModule({
  declarations: [
    RecordingPage,
  ],
  imports: [
    IonicPageModule.forChild(RecordingPage),
  ],
  exports: [
    RecordingPage
  ]
})
export class RecordingPageModule {}
