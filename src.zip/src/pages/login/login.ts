import { Component } from '@angular/core';
import { Platform, IonicPage, NavController, AlertController, LoadingController, Loading } from 'ionic-angular';
import { HomePage } from '../home/home';
import { AuthProvider } from '../../providers/authProvider';
import { User } from '../../app/models/user';
import { UserService } from '../../app/services/user.service';
import { BranchService } from '../../app/services/branch.service';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})

export class LoginPage {
  loading: Loading;
  userName: string;
  password: string;

  constructor(public nav: NavController, private alertCtrl: AlertController, private loadingCtrl: LoadingController, private authProvider: AuthProvider, private platform: Platform, private branchService: BranchService, private userService: UserService) {
    platform.resume.subscribe(() => {
      this.authProvider.retrieveAuthToken().then((data) => {
        this.checkToken(data);
      });
    });
  }

  checkToken(token) {
    this.authProvider.validateToken(token).subscribe(
      (data) => {
        // if(data && data.Message) {
          //TODO How do we get a new token?
        // }
      },
       (error) => {
         console.log(error);
       });
  }

  public userLogin() {
    this.showLoading();
    this.authProvider.callLoginApi(this.userName, this.password).subscribe(
      (data) => {
        // console.log("In here, logged In", data.access_token);
        this.authProvider.storeAuthToken(data.access_token);
        this.userService.findOrCreateUser(this.userName);
        this.nav.setRoot(HomePage);
        // this.userService.findOrCreateUser(this.userName);
        // this.nav.setRoot(HomePage);
      },
       (error) => {this.showError(error.json)});

  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
  }

  showError(text) {
    this.loading.dismiss();
    let alert = this.alertCtrl.create({
      title: 'Something isn\'t working right. Try again.',
      subTitle: text,
      buttons: ['OK']
    });
    alert.present(prompt);
  }

  createUser(username){
    // this.userService.


    // branch data
    // let branchList = this.branchService.getBranches();
    // console.log('branches', branchList);
    // this.dataStore.getBranches().then((branches) => {
    //   this.createBranches(JSON.parse(branches));
    // })

    // this.dataStore.getUser(userName).then((res) => {
    //   if(!res){
    //     let alert = this.alertCtrl.create({
    //       title: 'Choose Branch',
    //       inputs: [
    //         {
    //           type: 'radio',
    //           label: branchList[0],
    //           value: branchList[0]
    //         }
    //       ]
    //     })
    //   }
    // })
  }

}
