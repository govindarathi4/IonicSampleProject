import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CreateObservationPage } from '../create-observation/create-observation';
import { CreateNotePage } from '../create-note/create-note';
import { RecordingPage } from '../recording/recording';
import { Recording } from '../../app/models/recording';
import { Observation } from '../../app/models/observation';

import { Note } from '../../app/models/note';
import { RecordingService } from '../../app/services/recording.service';
import { Template } from '../../app/models/template';
import { TemplateService } from '../../app/services/template.service';
import { MachineService } from '../../app/services/machine.service';


@IonicPage()
@Component({
  selector: 'page-pre-recording',
  templateUrl: 'pre-recording.html',
})
export class PreRecordingPage {

  machine;
  recording: Recording;
  notes: Note[] = [];
  observations: Observation[] = [];
  observationForm: FormGroup;
    templates: Template[] = this.templateService.templates;
    answer1: string;
    answer2: string;
    answer3: string;


  constructor(public navCtrl: NavController, public navParams: NavParams, public recordingService: RecordingService,  public formBuilder: FormBuilder, public templateService: TemplateService, public machineService: MachineService) {
    this.machine = navParams.get('machine');
    this.recording = navParams.get('recording');

    this.observationForm = formBuilder.group({
      question1: [''],
      question2: [''],
      question3: ['']
    });
  }

  ionViewWillEnter() {
    console.log("Pre Recording!", this.recording.recordingId);
    this.observations = this.recordingService.getObservations(this.recording.recordingId);
    console.log(this.observations);
    this.notes = this.machineService.getNotes(this.machine.machineSerial);
    console.log("Notes in Ion View Will Enter", this.notes);
  }

  addNewObservation(){
    this.navCtrl.push(CreateObservationPage, {machine: this.machine, recordingId: this.recording.recordingId});
  }

  addNewNote(){
    this.navCtrl.push(CreateNotePage, {machine: this.machine, recordingId: this.recording.recordingId});
  }

  goToRecording(){
    this.navCtrl.push(RecordingPage, { machine:this.machine, recording: this.recording});
  }

  question1Options(){
      let options = [];

      this.templates.forEach(function(template){
        if (template.make && options.indexOf(template.make) < 0){
          options.push(template.make);
        }
      });

      return options;
    }

    question2Options(){
      let options = [];
      let make = this.answer1;
      if (this.answer1 != null || this.answer1 != undefined){
        this.templates.forEach(function(template){
          if (template.make == make && template.model && options.indexOf(template.model) < 0){
            options.push(template.model);
          }
        });
        return options;
      }
    }

    question3Options(){
      let options = [];
      let make = this.answer1;
      let model = this.answer2;
      if ((this.answer1 != null || this.answer1 != undefined) && (this.answer2 != null || this.answer2 != undefined)){
        this.templates.forEach(function(template){
          if (template.make == make && template.model == model && template.templateName &&  options.indexOf(template.templateName) < 0){
            options.push(template.templateName);
          }
        });
        return options;
      }
    }

    getQuestion1(answer){
      this.answer1 = answer;
      console.log(answer);
    }

    getQuestion2(answer){
      this.answer2 = answer;
      console.log(answer);
    }

    getQuestion3(answer){
      this.answer3 = answer;
      console.log(answer);
    }
}
