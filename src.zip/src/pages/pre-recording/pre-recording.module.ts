import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PreRecordingPage } from './pre-recording';

@NgModule({
  declarations: [
    PreRecordingPage,
  ],
  imports: [
    IonicPageModule.forChild(PreRecordingPage),
  ],
  exports: [
    PreRecordingPage
  ]
})
export class PreRecordingPageModule {}
