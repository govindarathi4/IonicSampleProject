import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import "rxjs/add/operator/map";
import "rxjs/add/operator/toPromise";
import { Observable } from "rxjs/Observable";

@Injectable()
export class RequestMethodsService{

    constructor(private http: Http){

    }


    getJobs(baseUri: string, resourceUri: string, start: number, type: string){
        let uri = baseUri + resourceUri;
        let params: URLSearchParams = new URLSearchParams();
        params.set('startPoint', start.toString());
        params.set('jobType', type);
        let headers = new Headers({'Accept': 'application/json'});
        let options = new RequestOptions({ headers: headers, search: params });
        var response = this.http.get(uri, options).map(res => res.json());
        return response; 
    }

    getData(baseUri: string, resourceUri: string, argType?: string, id?: number, paramName? : string, id2?: number, paramName2?: string){
        let uri = baseUri + resourceUri;
        let params: URLSearchParams = new URLSearchParams();
        let headers = new Headers({'Accept': 'application/json'});
        let options;
        if(argType && argType == 'queryParam'){
            paramName = paramName || 'jobId';
            params.set(paramName, id.toString());
            if(id2){
                params.set(paramName2, id2.toString());
            }
            options = new RequestOptions({ headers: headers, search: params });
        }
        else if(argType && argType == 'resourceUriParam'){
            uri = uri + id;
            options = new RequestOptions({ headers: headers });
        }       
        var response = this.http.get(uri, options).map(res => res.json());
        return response;
    }

    postData(uri: string, postBody: any) {
        let body = JSON.stringify(postBody);
        let headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json'});
        var response = this.http.post(uri, body, { headers: headers }).map(res => res.json());
        return response;
    }

    putData(uri: string, body: any) {
        let data = JSON.stringify(body);
        let header = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json'});
        var response = this.http.put(uri, data, { headers : header }).map(res => res.json());
        return response;
    }

    deleteData(uri: string, body: any) {       
        let header = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json' });
        let options = new RequestOptions({ headers: header, body: body });
        var response = this.http.delete(uri, options).map(res => res.json());
        return response;
    }
}