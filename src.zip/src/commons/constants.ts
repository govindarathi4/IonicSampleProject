import { Injectable } from '@angular/core';

@Injectable()
export class Constants{
    //public BASE_URL:string = 'http://10.0.2.2/Athena.WebAPI/api/';
    //public BASE_URL:string = 'http://localhost/Athena.WebAPI/api/';
    public BASE_URL:string = 'http://athenawebapidemo.azurewebsites.net/api/';
    


    public GET_JOBS:string = 'jobs';
    public GET_JOB_BY_ID:string = 'jobs/';
    public GET_MACHINES:string = 'machines';
    public GET_BRANCHES:string = 'branches';
    public GET_CUSTOMERS:string = 'customers';
    public GET_BUILDINGS:string = 'buildings';
}